package com.cricket.score.dto;

import com.cricket.score.model.DismissalType;
import com.cricket.score.model.ExtraType;
import java.time.LocalDateTime;

public class CommentaryDto {
    private Long id;
    private int inningNumber;
    private String overString; // e.g. "14.3"
    private int overNumber;
    private int ballNumber;
    private String strikerName;
    private String nonStrikerName;
    private String bowlerName;
    private int runsOffBat;
    private int extraRuns;
    private ExtraType extraType;
    private boolean isWicket;
    private DismissalType dismissalType;
    private String dismissedPlayerName;
    private int totalRuns;
    private int totalWickets;
    private String commentary;
    private LocalDateTime timestamp;

    public CommentaryDto() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public int getInningNumber() { return inningNumber; }
    public void setInningNumber(int inningNumber) { this.inningNumber = inningNumber; }

    public String getOverString() { return overString; }
    public void setOverString(String overString) { this.overString = overString; }

    public int getOverNumber() { return overNumber; }
    public void setOverNumber(int overNumber) { this.overNumber = overNumber; }

    public int getBallNumber() { return ballNumber; }
    public void setBallNumber(int ballNumber) { this.ballNumber = ballNumber; }

    public String getStrikerName() { return strikerName; }
    public void setStrikerName(String strikerName) { this.strikerName = strikerName; }

    public String getNonStrikerName() { return nonStrikerName; }
    public void setNonStrikerName(String nonStrikerName) { this.nonStrikerName = nonStrikerName; }

    public String getBowlerName() { return bowlerName; }
    public void setBowlerName(String bowlerName) { this.bowlerName = bowlerName; }

    public int getRunsOffBat() { return runsOffBat; }
    public void setRunsOffBat(int runsOffBat) { this.runsOffBat = runsOffBat; }

    public int getExtraRuns() { return extraRuns; }
    public void setExtraRuns(int extraRuns) { this.extraRuns = extraRuns; }

    public ExtraType getExtraType() { return extraType; }
    public void setExtraType(ExtraType extraType) { this.extraType = extraType; }

    public boolean isWicket() { return isWicket; }
    public void setWicket(boolean wicket) { isWicket = wicket; }

    public DismissalType getDismissalType() { return dismissalType; }
    public void setDismissalType(DismissalType dismissalType) { this.dismissalType = dismissalType; }

    public String getDismissedPlayerName() { return dismissedPlayerName; }
    public void setDismissedPlayerName(String dismissedPlayerName) { this.dismissedPlayerName = dismissedPlayerName; }

    public int getTotalRuns() { return totalRuns; }
    public void setTotalRuns(int totalRuns) { this.totalRuns = totalRuns; }

    public int getTotalWickets() { return totalWickets; }
    public void setTotalWickets(int totalWickets) { this.totalWickets = totalWickets; }

    public String getCommentary() { return commentary; }
    public void setCommentary(String commentary) { this.commentary = commentary; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
}
