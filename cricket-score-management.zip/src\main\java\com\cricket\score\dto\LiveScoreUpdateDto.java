package com.cricket.score.dto;

import com.cricket.score.model.ExtraType;
import com.cricket.score.model.MatchStatus;
import java.util.List;

public class LiveScoreUpdateDto {
    private Long matchId;
    private String matchTitle;
    private String venue;
    private MatchStatus status;
    private String resultMessage;

    private int currentInningNumber;
    private String battingTeamName;
    private String battingTeamShort;
    private String battingTeamColor;

    private String bowlingTeamName;
    private String bowlingTeamShort;
    private String bowlingTeamColor;

    private int totalRuns;
    private int wickets;
    private String oversDisplay;
    private int completedOvers;
    private int ballsInCurrentOver;
    private int maxOvers;

    private Integer targetRuns;
    private Double requiredRunRate;
    private double currentRunRate;

    // Striker
    private String strikerName;
    private int strikerRuns;
    private int strikerBalls;
    private int strikerFours;
    private int strikerSixes;
    private double strikerStrikeRate;

    // Non-Striker
    private String nonStrikerName;
    private int nonStrikerRuns;
    private int nonStrikerBalls;
    private int nonStrikerFours;
    private int nonStrikerSixes;
    private double nonStrikerStrikeRate;

    // Bowler
    private String bowlerName;
    private String bowlerOvers;
    private int bowlerMaidens;
    private int bowlerRuns;
    private int bowlerWickets;
    private double bowlerEconomy;

    // Recent ball outcomes in current over/spell
    private List<String> recentDeliveries;
    private String lastBallCommentary;
    private String lastBallDisplay;

    // Event flags for UI flair/animation
    private boolean isFour;
    private boolean isSix;
    private boolean isWicket;
    private boolean isExtra;
    private ExtraType extraType;

    private boolean isSimulationActive;
    private int simulationSpeed;

    public LiveScoreUpdateDto() {}

    // Getters and Setters
    public Long getMatchId() { return matchId; }
    public void setMatchId(Long matchId) { this.matchId = matchId; }

    public String getMatchTitle() { return matchTitle; }
    public void setMatchTitle(String matchTitle) { this.matchTitle = matchTitle; }

    public String getVenue() { return venue; }
    public void setVenue(String venue) { this.venue = venue; }

    public MatchStatus getStatus() { return status; }
    public void setStatus(MatchStatus status) { this.status = status; }

    public String getResultMessage() { return resultMessage; }
    public void setResultMessage(String resultMessage) { this.resultMessage = resultMessage; }

    public int getCurrentInningNumber() { return currentInningNumber; }
    public void setCurrentInningNumber(int currentInningNumber) { this.currentInningNumber = currentInningNumber; }

    public String getBattingTeamName() { return battingTeamName; }
    public void setBattingTeamName(String battingTeamName) { this.battingTeamName = battingTeamName; }

    public String getBattingTeamShort() { return battingTeamShort; }
    public void setBattingTeamShort(String battingTeamShort) { this.battingTeamShort = battingTeamShort; }

    public String getBattingTeamColor() { return battingTeamColor; }
    public void setBattingTeamColor(String battingTeamColor) { this.battingTeamColor = battingTeamColor; }

    public String getBowlingTeamName() { return bowlingTeamName; }
    public void setBowlingTeamName(String bowlingTeamName) { this.bowlingTeamName = bowlingTeamName; }

    public String getBowlingTeamShort() { return bowlingTeamShort; }
    public void setBowlingTeamShort(String bowlingTeamShort) { this.bowlingTeamShort = bowlingTeamShort; }

    public String getBowlingTeamColor() { return bowlingTeamColor; }
    public void setBowlingTeamColor(String bowlingTeamColor) { this.bowlingTeamColor = bowlingTeamColor; }

    public int getTotalRuns() { return totalRuns; }
    public void setTotalRuns(int totalRuns) { this.totalRuns = totalRuns; }

    public int getWickets() { return wickets; }
    public void setWickets(int wickets) { this.wickets = wickets; }

    public String getOversDisplay() { return oversDisplay; }
    public void setOversDisplay(String oversDisplay) { this.oversDisplay = oversDisplay; }

    public int getCompletedOvers() { return completedOvers; }
    public void setCompletedOvers(int completedOvers) { this.completedOvers = completedOvers; }

    public int getBallsInCurrentOver() { return ballsInCurrentOver; }
    public void setBallsInCurrentOver(int ballsInCurrentOver) { this.ballsInCurrentOver = ballsInCurrentOver; }

    public int getMaxOvers() { return maxOvers; }
    public void setMaxOvers(int maxOvers) { this.maxOvers = maxOvers; }

    public Integer getTargetRuns() { return targetRuns; }
    public void setTargetRuns(Integer targetRuns) { this.targetRuns = targetRuns; }

    public Double getRequiredRunRate() { return requiredRunRate; }
    public void setRequiredRunRate(Double requiredRunRate) { this.requiredRunRate = requiredRunRate; }

    public double getCurrentRunRate() { return currentRunRate; }
    public void setCurrentRunRate(double currentRunRate) { this.currentRunRate = currentRunRate; }

    public String getStrikerName() { return strikerName; }
    public void setStrikerName(String strikerName) { this.strikerName = strikerName; }

    public int getStrikerRuns() { return strikerRuns; }
    public void setStrikerRuns(int strikerRuns) { this.strikerRuns = strikerRuns; }

    public int getStrikerBalls() { return strikerBalls; }
    public void setStrikerBalls(int strikerBalls) { this.strikerBalls = strikerBalls; }

    public int getStrikerFours() { return strikerFours; }
    public void setStrikerFours(int strikerFours) { this.strikerFours = strikerFours; }

    public int getStrikerSixes() { return strikerSixes; }
    public void setStrikerSixes(int strikerSixes) { this.strikerSixes = strikerSixes; }

    public double getStrikerStrikeRate() { return strikerStrikeRate; }
    public void setStrikerStrikeRate(double strikerStrikeRate) { this.strikerStrikeRate = strikerStrikeRate; }

    public String getNonStrikerName() { return nonStrikerName; }
    public void setNonStrikerName(String nonStrikerName) { this.nonStrikerName = nonStrikerName; }

    public int getNonStrikerRuns() { return nonStrikerRuns; }
    public void setNonStrikerRuns(int nonStrikerRuns) { this.nonStrikerRuns = nonStrikerRuns; }

    public int getNonStrikerBalls() { return nonStrikerBalls; }
    public void setNonStrikerBalls(int nonStrikerBalls) { this.nonStrikerBalls = nonStrikerBalls; }

    public int getNonStrikerFours() { return nonStrikerFours; }
    public void setNonStrikerFours(int nonStrikerFours) { this.nonStrikerFours = nonStrikerFours; }

    public int getNonStrikerSixes() { return nonStrikerSixes; }
    public void setNonStrikerSixes(int nonStrikerSixes) { this.nonStrikerSixes = nonStrikerSixes; }

    public double getNonStrikerStrikeRate() { return nonStrikerStrikeRate; }
    public void setNonStrikerStrikeRate(double nonStrikerStrikeRate) { this.nonStrikerStrikeRate = nonStrikerStrikeRate; }

    public String getBowlerName() { return bowlerName; }
    public void setBowlerName(String bowlerName) { this.bowlerName = bowlerName; }

    public String getBowlerOvers() { return bowlerOvers; }
    public void setBowlerOvers(String bowlerOvers) { this.bowlerOvers = bowlerOvers; }

    public int getBowlerMaidens() { return bowlerMaidens; }
    public void setBowlerMaidens(int bowlerMaidens) { this.bowlerMaidens = bowlerMaidens; }

    public int getBowlerRuns() { return bowlerRuns; }
    public void setBowlerRuns(int bowlerRuns) { this.bowlerRuns = bowlerRuns; }

    public int getBowlerWickets() { return bowlerWickets; }
    public void setBowlerWickets(int bowlerWickets) { this.bowlerWickets = bowlerWickets; }

    public double getBowlerEconomy() { return bowlerEconomy; }
    public void setBowlerEconomy(double bowlerEconomy) { this.bowlerEconomy = bowlerEconomy; }

    public List<String> getRecentDeliveries() { return recentDeliveries; }
    public void setRecentDeliveries(List<String> recentDeliveries) { this.recentDeliveries = recentDeliveries; }

    public String getLastBallCommentary() { return lastBallCommentary; }
    public void setLastBallCommentary(String lastBallCommentary) { this.lastBallCommentary = lastBallCommentary; }

    public String getLastBallDisplay() { return lastBallDisplay; }
    public void setLastBallDisplay(String lastBallDisplay) { this.lastBallDisplay = lastBallDisplay; }

    public boolean isFour() { return isFour; }
    public void setFour(boolean four) { isFour = four; }

    public boolean isSix() { return isSix; }
    public void setSix(boolean six) { isSix = six; }

    public boolean isWicket() { return isWicket; }
    public void setWicket(boolean wicket) { isWicket = wicket; }

    public boolean isExtra() { return isExtra; }
    public void setExtra(boolean extra) { isExtra = extra; }

    public ExtraType getExtraType() { return extraType; }
    public void setExtraType(ExtraType extraType) { this.extraType = extraType; }

    public boolean isSimulationActive() { return isSimulationActive; }
    public void setSimulationActive(boolean simulationActive) { isSimulationActive = simulationActive; }

    public int getSimulationSpeed() { return simulationSpeed; }
    public void setSimulationSpeed(int simulationSpeed) { this.simulationSpeed = simulationSpeed; }
}
