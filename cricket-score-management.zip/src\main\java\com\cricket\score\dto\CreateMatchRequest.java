package com.cricket.score.dto;

import com.cricket.score.model.MatchFormat;

public class CreateMatchRequest {
    private String title;
    private String venue;
    private MatchFormat format = MatchFormat.T20;
    private int maxOvers = 20;
    private String team1Name;
    private String team1Short;
    private String team1Color;
    private String team2Name;
    private String team2Short;
    private String team2Color;
    private String tossWinnerTeam; // "team1" or "team2"
    private String tossDecision; // "bat" or "bowl"

    public CreateMatchRequest() {}

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getVenue() { return venue; }
    public void setVenue(String venue) { this.venue = venue; }

    public MatchFormat getFormat() { return format; }
    public void setFormat(MatchFormat format) { this.format = format; }

    public int getMaxOvers() { return maxOvers; }
    public void setMaxOvers(int maxOvers) { this.maxOvers = maxOvers; }

    public String getTeam1Name() { return team1Name; }
    public void setTeam1Name(String team1Name) { this.team1Name = team1Name; }

    public String getTeam1Short() { return team1Short; }
    public void setTeam1Short(String team1Short) { this.team1Short = team1Short; }

    public String getTeam1Color() { return team1Color; }
    public void setTeam1Color(String team1Color) { this.team1Color = team1Color; }

    public String getTeam2Name() { return team2Name; }
    public void setTeam2Name(String team2Name) { this.team2Name = team2Name; }

    public String getTeam2Short() { return team2Short; }
    public void setTeam2Short(String team2Short) { this.team2Short = team2Short; }

    public String getTeam2Color() { return team2Color; }
    public void setTeam2Color(String team2Color) { this.team2Color = team2Color; }

    public String getTossWinnerTeam() { return tossWinnerTeam; }
    public void setTossWinnerTeam(String tossWinnerTeam) { this.tossWinnerTeam = tossWinnerTeam; }

    public String getTossDecision() { return tossDecision; }
    public void setTossDecision(String tossDecision) { this.tossDecision = tossDecision; }
}
