package com.cricket.score.repository;

import com.cricket.score.model.Inning;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface InningRepository extends JpaRepository<Inning, Long> {
    List<Inning> findByMatchIdOrderByInningNumberAsc(Long matchId);
}
