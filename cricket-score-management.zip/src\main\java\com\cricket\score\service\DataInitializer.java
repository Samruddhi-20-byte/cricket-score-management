package com.cricket.score.service;

import com.cricket.score.model.*;
import com.cricket.score.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Component
public class DataInitializer implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataInitializer.class);

    private final TeamRepository teamRepository;
    private final PlayerRepository playerRepository;
    private final MatchRepository matchRepository;
    private final InningRepository inningRepository;
    private final BattingRecordRepository battingRecordRepository;
    private final BowlingRecordRepository bowlingRecordRepository;
    private final BallDeliveryRepository ballDeliveryRepository;
    private final MatchSimulationEngine simulationEngine;

    public DataInitializer(
            TeamRepository teamRepository,
            PlayerRepository playerRepository,
            MatchRepository matchRepository,
            InningRepository inningRepository,
            BattingRecordRepository battingRecordRepository,
            BowlingRecordRepository bowlingRecordRepository,
            BallDeliveryRepository ballDeliveryRepository,
            MatchSimulationEngine simulationEngine
    ) {
        this.teamRepository = teamRepository;
        this.playerRepository = playerRepository;
        this.matchRepository = matchRepository;
        this.inningRepository = inningRepository;
        this.battingRecordRepository = battingRecordRepository;
        this.bowlingRecordRepository = bowlingRecordRepository;
        this.ballDeliveryRepository = ballDeliveryRepository;
        this.simulationEngine = simulationEngine;
    }

    @Override
    @Transactional
    public void run(String... args) {
        if (teamRepository.count() > 0) return;
        log.info("Initializing Cricket Data: Teams, Players, and Seed Matches...");

        // Create Teams and Players
        Team india = createTeam("India", "IND", "#1e3a8a", "#0284c7");
        Team australia = createTeam("Australia", "AUS", "#eab308", "#15803d");
        Team england = createTeam("England", "ENG", "#dc2626", "#1e40af");
        Team southAfrica = createTeam("South Africa", "SA", "#15803d", "#facc15");

        // Seed Players for India
        List<Player> indSquad = List.of(
                createPlayer("Rohit Sharma", PlayerRole.BATSMAN, "India"),
                createPlayer("Virat Kohli", PlayerRole.BATSMAN, "India"),
                createPlayer("Suryakumar Yadav", PlayerRole.BATSMAN, "India"),
                createPlayer("Rishabh Pant", PlayerRole.WICKET_KEEPER, "India"),
                createPlayer("Hardik Pandya", PlayerRole.ALL_ROUNDER, "India"),
                createPlayer("Rinku Singh", PlayerRole.BATSMAN, "India"),
                createPlayer("Axar Patel", PlayerRole.ALL_ROUNDER, "India"),
                createPlayer("Ravindra Jadeja", PlayerRole.ALL_ROUNDER, "India"),
                createPlayer("Jasprit Bumrah", PlayerRole.BOWLER, "India"),
                createPlayer("Arshdeep Singh", PlayerRole.BOWLER, "India"),
                createPlayer("Mohammed Siraj", PlayerRole.BOWLER, "India")
        );
        indSquad.forEach(india::addPlayer);
        teamRepository.save(india);

        // Seed Players for Australia
        List<Player> ausSquad = List.of(
                createPlayer("Travis Head", PlayerRole.BATSMAN, "Australia"),
                createPlayer("David Warner", PlayerRole.BATSMAN, "Australia"),
                createPlayer("Mitchell Marsh", PlayerRole.ALL_ROUNDER, "Australia"),
                createPlayer("Glenn Maxwell", PlayerRole.ALL_ROUNDER, "Australia"),
                createPlayer("Marcus Stoinis", PlayerRole.ALL_ROUNDER, "Australia"),
                createPlayer("Tim David", PlayerRole.BATSMAN, "Australia"),
                createPlayer("Matthew Wade", PlayerRole.WICKET_KEEPER, "Australia"),
                createPlayer("Pat Cummins", PlayerRole.BOWLER, "Australia"),
                createPlayer("Mitchell Starc", PlayerRole.BOWLER, "Australia"),
                createPlayer("Adam Zampa", PlayerRole.BOWLER, "Australia"),
                createPlayer("Josh Hazlewood", PlayerRole.BOWLER, "Australia")
        );
        ausSquad.forEach(australia::addPlayer);
        teamRepository.save(australia);

        // Seed Players for England
        List<Player> engSquad = List.of(
                createPlayer("Jos Buttler", PlayerRole.WICKET_KEEPER, "England"),
                createPlayer("Phil Salt", PlayerRole.BATSMAN, "England"),
                createPlayer("Jonny Bairstow", PlayerRole.BATSMAN, "England"),
                createPlayer("Harry Brook", PlayerRole.BATSMAN, "England"),
                createPlayer("Liam Livingstone", PlayerRole.ALL_ROUNDER, "England"),
                createPlayer("Moeen Ali", PlayerRole.ALL_ROUNDER, "England"),
                createPlayer("Sam Curran", PlayerRole.ALL_ROUNDER, "England"),
                createPlayer("Chris Jordan", PlayerRole.BOWLER, "England"),
                createPlayer("Adil Rashid", PlayerRole.BOWLER, "England"),
                createPlayer("Jofra Archer", PlayerRole.BOWLER, "England"),
                createPlayer("Mark Wood", PlayerRole.BOWLER, "England")
        );
        engSquad.forEach(england::addPlayer);
        teamRepository.save(england);

        // Seed Players for South Africa
        List<Player> saSquad = List.of(
                createPlayer("Quinton de Kock", PlayerRole.WICKET_KEEPER, "South Africa"),
                createPlayer("Reeza Hendricks", PlayerRole.BATSMAN, "South Africa"),
                createPlayer("Aiden Markram", PlayerRole.BATSMAN, "South Africa"),
                createPlayer("Heinrich Klaasen", PlayerRole.BATSMAN, "South Africa"),
                createPlayer("David Miller", PlayerRole.BATSMAN, "South Africa"),
                createPlayer("Tristan Stubbs", PlayerRole.BATSMAN, "South Africa"),
                createPlayer("Marco Jansen", PlayerRole.ALL_ROUNDER, "South Africa"),
                createPlayer("Keshav Maharaj", PlayerRole.BOWLER, "South Africa"),
                createPlayer("Kagiso Rabada", PlayerRole.BOWLER, "South Africa"),
                createPlayer("Anrich Nortje", PlayerRole.BOWLER, "South Africa"),
                createPlayer("Tabraiz Shamsi", PlayerRole.BOWLER, "South Africa")
        );
        saSquad.forEach(southAfrica::addPlayer);
        teamRepository.save(southAfrica);

        // Seed Match 1: ICC Men's T20 World Cup Final (India vs Australia)
        createT20WorldCupFinal(india, australia, indSquad, ausSquad);

        // Seed Match 2: South Africa vs England
        createBilateralT20(southAfrica, england, saSquad, engSquad);

        log.info("Cricket Data initialized successfully.");
    }

    private void createT20WorldCupFinal(Team india, Team australia, List<Player> ind, List<Player> aus) {
        Match match = new Match();
        match.setTitle("ICC Men's T20 World Cup 2026 - Final");
        match.setVenue("Melbourne Cricket Ground, Melbourne");
        match.setFormat(MatchFormat.T20);
        match.setMaxOvers(20);
        match.setStatus(MatchStatus.LIVE);
        match.setTeam1(india);
        match.setTeam2(australia);
        match.setTossWinner(australia);
        match.setTossDecision("bowl");
        match.setCurrentInningIndex(1);
        match.setSimulationActive(true);
        match.setSimulationSpeed(1);
        match.setResultMessage("Australia need 37 runs in 22 balls.");

        match = matchRepository.save(match);

        // Inning 1: India batting (completed 20 overs, 182/6)
        Inning inn1 = new Inning(match, 1, india, australia);
        inn1.setStatus(InningStatus.COMPLETED);
        inn1.setTotalRuns(182);
        inn1.setWickets(6);
        inn1.setCompletedOvers(20);
        inn1.setBallsInCurrentOver(0);
        inn1.setWides(5);
        inn1.setNoBalls(1);
        inn1.setByes(2);
        inn1.setLegByes(2);
        inn1 = inningRepository.save(inn1);

        // India batting card
        seedBattingRecord(inn1, ind.get(0), 48, 28, 6, 2, true, DismissalType.CAUGHT, "M. Starc", "T. Head", 1);
        seedBattingRecord(inn1, ind.get(1), 76, 51, 8, 3, true, DismissalType.BOWLED, "P. Cummins", null, 2);
        seedBattingRecord(inn1, ind.get(2), 22, 14, 2, 1, true, DismissalType.CAUGHT, "A. Zampa", "G. Maxwell", 3);
        seedBattingRecord(inn1, ind.get(3), 15, 11, 1, 0, true, DismissalType.LBW, "M. Starc", null, 4);
        seedBattingRecord(inn1, ind.get(4), 12, 9, 1, 1, false, DismissalType.NOT_OUT, null, null, 5);
        seedBattingRecord(inn1, ind.get(5), 4, 3, 0, 0, true, DismissalType.RUN_OUT, null, "M. Stoinis", 6);
        seedBattingRecord(inn1, ind.get(6), 0, 1, 0, 0, true, DismissalType.BOWLED, "J. Hazlewood", null, 7);
        seedBattingRecord(inn1, ind.get(7), 1, 3, 0, 0, false, DismissalType.NOT_OUT, null, null, 8);

        // Australia bowling figures
        seedBowlingRecord(inn1, aus.get(8), 4, 0, 36, 2, 1); // Starc
        seedBowlingRecord(inn1, aus.get(10), 4, 0, 32, 1, 2); // Hazlewood
        seedBowlingRecord(inn1, aus.get(7), 4, 0, 38, 1, 3); // Cummins
        seedBowlingRecord(inn1, aus.get(9), 4, 0, 39, 1, 4); // Zampa
        seedBowlingRecord(inn1, aus.get(4), 4, 0, 33, 0, 5); // Stoinis

        // Inning 1 ball deliveries summary snapshots (for Manhattan & Worm charts)
        int cumulative = 0;
        int[] overRuns = {10, 8, 12, 6, 14, 11, 7, 9, 8, 12, 10, 6, 15, 8, 9, 11, 7, 13, 8, 18};
        for (int ov = 0; ov < 20; ov++) {
            cumulative += overRuns[ov];
            BallDelivery bd = new BallDelivery();
            bd.setInning(inn1);
            bd.setOverNumber(ov);
            bd.setBallNumberInOver(6);
            bd.setLegalDelivery(true);
            bd.setStriker(ind.get(1));
            bd.setBowler(aus.get(8));
            bd.setRunsOffBat(1);
            bd.setTotalInningRunsAtBall(cumulative);
            bd.setTotalInningWicketsAtBall(ov == 4 ? 1 : (ov == 11 ? 2 : (ov == 14 ? 3 : (ov == 17 ? 4 : (ov == 18 ? 5 : (ov == 19 ? 6 : 0))))));
            bd.setCommentary("End of over " + (ov + 1) + ". India " + cumulative + "/" + bd.getTotalInningWicketsAtBall());
            ballDeliveryRepository.save(bd);
        }

        // Inning 2: Australia batting (Target 183, 146/4 in 16.2 overs)
        Inning inn2 = new Inning(match, 2, australia, india);
        inn2.setStatus(InningStatus.IN_PROGRESS);
        inn2.setTargetRuns(183);
        inn2.setTotalRuns(146);
        inn2.setWickets(4);
        inn2.setCompletedOvers(16);
        inn2.setBallsInCurrentOver(2);
        inn2.setWides(4);
        inn2.setNoBalls(0);
        inn2.setByes(0);
        inn2.setLegByes(2);

        // Active players
        inn2.setCurrentStrikerId(aus.get(4).getId()); // Marcus Stoinis (Striker)
        inn2.setCurrentNonStrikerId(aus.get(5).getId()); // Tim David (Non-Striker)
        inn2.setCurrentBowlerId(ind.get(8).getId()); // Jasprit Bumrah (Bowler)
        inn2 = inningRepository.save(inn2);

        match.getInnings().add(inn1);
        match.getInnings().add(inn2);
        matchRepository.save(match);

        // Australia batting records
        seedBattingRecord(inn2, aus.get(0), 42, 25, 5, 2, true, DismissalType.BOWLED, "J. Bumrah", null, 1);
        seedBattingRecord(inn2, aus.get(1), 28, 19, 3, 1, true, DismissalType.CAUGHT, "A. Singh", "V. Kohli", 2);
        seedBattingRecord(inn2, aus.get(2), 34, 26, 4, 1, true, DismissalType.LBW, "A. Patel", null, 3);
        seedBattingRecord(inn2, aus.get(3), 11, 8, 1, 0, true, DismissalType.CAUGHT, "H. Pandya", "R. Sharma", 4);
        BattingRecord stoinisRec = seedBattingRecord(inn2, aus.get(4), 18, 11, 2, 0, false, DismissalType.NOT_OUT, null, null, 5);
        stoinisRec.setBatting(true);
        stoinisRec.setOnStrike(true);
        battingRecordRepository.save(stoinisRec);

        BattingRecord davidRec = seedBattingRecord(inn2, aus.get(5), 9, 6, 1, 0, false, DismissalType.NOT_OUT, null, null, 6);
        davidRec.setBatting(true);
        davidRec.setOnStrike(false);
        battingRecordRepository.save(davidRec);

        // India bowling figures in Inning 2
        seedBowlingRecord(inn2, ind.get(9), 4, 0, 36, 1, 1); // Arshdeep
        seedBowlingRecord(inn2, ind.get(10), 3, 0, 31, 0, 2); // Siraj
        BowlingRecord bumrahRec = seedBowlingRecord(inn2, ind.get(8), 3, 0, 22, 1, 3); // Bumrah
        bumrahRec.setBallsInCurrentOver(2);
        bumrahRec.setCurrentBowler(true);
        bowlingRecordRepository.save(bumrahRec);

        seedBowlingRecord(inn2, ind.get(6), 4, 0, 29, 1, 4); // Axar
        seedBowlingRecord(inn2, ind.get(4), 2, 0, 24, 1, 5); // Hardik

        // Deliveries for Inning 2
        int[] ausOverRuns = {11, 9, 14, 8, 10, 12, 7, 9, 11, 8, 10, 7, 12, 6, 8, 10};
        int ausCum = 0;
        for (int ov = 0; ov < 16; ov++) {
            ausCum += ausOverRuns[ov];
            BallDelivery bd = new BallDelivery();
            bd.setInning(inn2);
            bd.setOverNumber(ov);
            bd.setBallNumberInOver(6);
            bd.setLegalDelivery(true);
            bd.setStriker(aus.get(4));
            bd.setBowler(ind.get(8));
            bd.setRunsOffBat(1);
            bd.setTotalInningRunsAtBall(ausCum);
            bd.setTotalInningWicketsAtBall(ov == 5 ? 1 : (ov == 8 ? 2 : (ov == 11 ? 3 : (ov == 14 ? 4 : 0))));
            bd.setCommentary("End of over " + (ov + 1) + ". Australia " + ausCum + "/" + bd.getTotalInningWicketsAtBall());
            ballDeliveryRepository.save(bd);
        }

        // Two balls in over 17
        BallDelivery b1 = new BallDelivery();
        b1.setInning(inn2);
        b1.setOverNumber(16);
        b1.setBallNumberInOver(1);
        b1.setLegalDelivery(true);
        b1.setStriker(aus.get(4));
        b1.setBowler(ind.get(8));
        b1.setRunsOffBat(1);
        b1.setTotalInningRunsAtBall(145);
        b1.setTotalInningWicketsAtBall(4);
        b1.setCommentary("Bumrah to Stoinis, 1 run. Yorker on middle, dug out through mid-wicket for a single.");
        ballDeliveryRepository.save(b1);

        BallDelivery b2 = new BallDelivery();
        b2.setInning(inn2);
        b2.setOverNumber(16);
        b2.setBallNumberInOver(2);
        b2.setLegalDelivery(true);
        b2.setStriker(aus.get(5));
        b2.setBowler(ind.get(8));
        b2.setRunsOffBat(1);
        b2.setTotalInningRunsAtBall(146);
        b2.setTotalInningWicketsAtBall(4);
        b2.setCommentary("Bumrah to Tim David, 1 run. Change of pace, pushed softly towards cover point to steal a quick single.");
        ballDeliveryRepository.save(b2);

        // Start simulation in background for live thrill!
        simulationEngine.startSimulation(match.getId(), 1);
    }

    private void createBilateralT20(Team sa, Team eng, List<Player> saSquad, List<Player> engSquad) {
        Match match = new Match();
        match.setTitle("England tour of South Africa 2026 - 1st T20I");
        match.setVenue("New Wanderers Stadium, Johannesburg");
        match.setFormat(MatchFormat.T20);
        match.setMaxOvers(20);
        match.setStatus(MatchStatus.SCHEDULED);
        match.setTeam1(sa);
        match.setTeam2(eng);
        match.setTossWinner(eng);
        match.setTossDecision("bowl");
        match.setCurrentInningIndex(0);
        match.setResultMessage("Match scheduled. South Africa to bat first.");
        match = matchRepository.save(match);

        Inning inn1 = new Inning(match, 1, sa, eng);
        inn1.setStatus(InningStatus.YET_TO_BAT);
        inn1 = inningRepository.save(inn1);

        Inning inn2 = new Inning(match, 2, eng, sa);
        inn2.setStatus(InningStatus.YET_TO_BAT);
        inn2 = inningRepository.save(inn2);

        match.getInnings().add(inn1);
        match.getInnings().add(inn2);
        matchRepository.save(match);
    }

    private Team createTeam(String name, String shortName, String primaryColor, String secondaryColor) {
        return teamRepository.save(new Team(name, shortName, primaryColor, secondaryColor));
    }

    private Player createPlayer(String name, PlayerRole role, String nationality) {
        return playerRepository.save(new Player(name, role, nationality));
    }

    private BattingRecord seedBattingRecord(Inning inning, Player player, int runs, int balls, int fours, int sixes,
                                            boolean isOut, DismissalType type, String bowler, String fielder, int pos) {
        BattingRecord br = new BattingRecord(player, inning, pos);
        br.setRunsScored(runs);
        br.setBallsFaced(balls);
        br.setFours(fours);
        br.setSixes(sixes);
        br.setOut(isOut);
        br.setDismissalType(type);
        br.setBowlerName(bowler);
        br.setFielderName(fielder);
        return battingRecordRepository.save(br);
    }

    private BowlingRecord seedBowlingRecord(Inning inning, Player player, int overs, int maidens, int runs, int wickets, int pos) {
        BowlingRecord br = new BowlingRecord(player, inning, pos);
        br.setCompletedOvers(overs);
        br.setMaidenOvers(maidens);
        br.setRunsConceded(runs);
        br.setWickets(wickets);
        return bowlingRecordRepository.save(br);
    }
}
