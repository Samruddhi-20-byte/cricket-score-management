package com.cricket.score.service;

import com.cricket.score.dto.LiveScoreUpdateDto;
import com.cricket.score.dto.MatchSummaryDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

@Service
public class WebSocketNotificationService {

    private static final Logger log = LoggerFactory.getLogger(WebSocketNotificationService.class);

    private final SimpMessagingTemplate messagingTemplate;

    public WebSocketNotificationService(SimpMessagingTemplate messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }

    public void notifyLiveScoreUpdate(LiveScoreUpdateDto update) {
        if (update == null || update.getMatchId() == null) return;
        String destination = "/topic/match/" + update.getMatchId();
        log.debug("Publishing live score update to {}: score={}/{} ov={}",
                destination, update.getTotalRuns(), update.getWickets(), update.getOversDisplay());
        messagingTemplate.convertAndSend(destination, update);
    }

    public void notifyMatchSummaryUpdate(MatchSummaryDto summary) {
        if (summary == null) return;
        log.debug("Publishing match summary update to /topic/matches for matchId={}", summary.getId());
        messagingTemplate.convertAndSend("/topic/matches", summary);
    }
}
