package com.cricket.score.model;

public enum InningStatus {
    YET_TO_BAT,
    IN_PROGRESS,
    COMPLETED
}
