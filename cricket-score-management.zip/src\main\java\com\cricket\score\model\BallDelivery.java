package com.cricket.score.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "ball_deliveries")
public class BallDelivery {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "inning_id", nullable = false)
    private Inning inning;

    private int overNumber; // 0 for first over, 1 for second...
    private int ballNumberInOver; // 1 to 6
    private boolean isLegalDelivery = true;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "striker_id")
    private Player striker;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "non_striker_id")
    private Player nonStriker;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "bowler_id")
    private Player bowler;

    private int runsOffBat = 0;
    private int extraRuns = 0;

    @Enumerated(EnumType.STRING)
    private ExtraType extraType = ExtraType.NONE;

    private boolean isWicket = false;

    @Enumerated(EnumType.STRING)
    private DismissalType dismissalType = DismissalType.NOT_OUT;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "dismissed_player_id")
    private Player dismissedPlayer;

    private int totalInningRunsAtBall;
    private int totalInningWicketsAtBall;

    @Column(length = 500)
    private String commentary;

    private LocalDateTime timestamp = LocalDateTime.now();

    public BallDelivery() {}

    public int getTotalRunsOnBall() {
        return runsOffBat + extraRuns;
    }

    public String getOverString() {
        return overNumber + "." + ballNumberInOver;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Inning getInning() {
        return inning;
    }

    public void setInning(Inning inning) {
        this.inning = inning;
    }

    public int getOverNumber() {
        return overNumber;
    }

    public void setOverNumber(int overNumber) {
        this.overNumber = overNumber;
    }

    public int getBallNumberInOver() {
        return ballNumberInOver;
    }

    public void setBallNumberInOver(int ballNumberInOver) {
        this.ballNumberInOver = ballNumberInOver;
    }

    public boolean isLegalDelivery() {
        return isLegalDelivery;
    }

    public void setLegalDelivery(boolean legalDelivery) {
        isLegalDelivery = legalDelivery;
    }

    public Player getStriker() {
        return striker;
    }

    public void setStriker(Player striker) {
        this.striker = striker;
    }

    public Player getNonStriker() {
        return nonStriker;
    }

    public void setNonStriker(Player nonStriker) {
        this.nonStriker = nonStriker;
    }

    public Player getBowler() {
        return bowler;
    }

    public void setBowler(Player bowler) {
        this.bowler = bowler;
    }

    public int getRunsOffBat() {
        return runsOffBat;
    }

    public void setRunsOffBat(int runsOffBat) {
        this.runsOffBat = runsOffBat;
    }

    public int getExtraRuns() {
        return extraRuns;
    }

    public void setExtraRuns(int extraRuns) {
        this.extraRuns = extraRuns;
    }

    public ExtraType getExtraType() {
        return extraType;
    }

    public void setExtraType(ExtraType extraType) {
        this.extraType = extraType;
    }

    public boolean isWicket() {
        return isWicket;
    }

    public void setWicket(boolean wicket) {
        isWicket = wicket;
    }

    public DismissalType getDismissalType() {
        return dismissalType;
    }

    public void setDismissalType(DismissalType dismissalType) {
        this.dismissalType = dismissalType;
    }

    public Player getDismissedPlayer() {
        return dismissedPlayer;
    }

    public void setDismissedPlayer(Player dismissedPlayer) {
        this.dismissedPlayer = dismissedPlayer;
    }

    public int getTotalInningRunsAtBall() {
        return totalInningRunsAtBall;
    }

    public void setTotalInningRunsAtBall(int totalInningRunsAtBall) {
        this.totalInningRunsAtBall = totalInningRunsAtBall;
    }

    public int getTotalInningWicketsAtBall() {
        return totalInningWicketsAtBall;
    }

    public void setTotalInningWicketsAtBall(int totalInningWicketsAtBall) {
        this.totalInningWicketsAtBall = totalInningWicketsAtBall;
    }

    public String getCommentary() {
        return commentary;
    }

    public void setCommentary(String commentary) {
        this.commentary = commentary;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }
}
