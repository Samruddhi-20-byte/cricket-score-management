package com.cricket.score.dto;

import java.util.ArrayList;
import java.util.List;

public class AnalyticsDto {
    private Long matchId;
    private String matchTitle;

    // Manhattan Chart: Runs scored in each over + wickets in that over
    private List<OverRunStats> team1OverRuns = new ArrayList<>();
    private List<OverRunStats> team2OverRuns = new ArrayList<>();

    // Worm Chart: Cumulative runs over by over
    private List<CumulativeOverStats> team1Worm = new ArrayList<>();
    private List<CumulativeOverStats> team2Worm = new ArrayList<>();

    public static class OverRunStats {
        private int overNumber; // 1, 2, 3...
        private int runs;
        private int wickets;

        public OverRunStats() {}

        public OverRunStats(int overNumber, int runs, int wickets) {
            this.overNumber = overNumber;
            this.runs = runs;
            this.wickets = wickets;
        }

        public int getOverNumber() { return overNumber; }
        public void setOverNumber(int overNumber) { this.overNumber = overNumber; }

        public int getRuns() { return runs; }
        public void setRuns(int runs) { this.runs = runs; }

        public int getWickets() { return wickets; }
        public void setWickets(int wickets) { this.wickets = wickets; }
    }

    public static class CumulativeOverStats {
        private double over; // e.g. 1.0, 2.0 or 14.3
        private int cumulativeRuns;
        private int wickets;

        public CumulativeOverStats() {}

        public CumulativeOverStats(double over, int cumulativeRuns, int wickets) {
            this.over = over;
            this.cumulativeRuns = cumulativeRuns;
            this.wickets = wickets;
        }

        public double getOver() { return over; }
        public void setOver(double over) { this.over = over; }

        public int getCumulativeRuns() { return cumulativeRuns; }
        public void setCumulativeRuns(int cumulativeRuns) { this.cumulativeRuns = cumulativeRuns; }

        public int getWickets() { return wickets; }
        public void setWickets(int wickets) { this.wickets = wickets; }
    }

    public AnalyticsDto() {}

    public Long getMatchId() { return matchId; }
    public void setMatchId(Long matchId) { this.matchId = matchId; }

    public String getMatchTitle() { return matchTitle; }
    public void setMatchTitle(String matchTitle) { this.matchTitle = matchTitle; }

    public List<OverRunStats> getTeam1OverRuns() { return team1OverRuns; }
    public void setTeam1OverRuns(List<OverRunStats> team1OverRuns) { this.team1OverRuns = team1OverRuns; }

    public List<OverRunStats> getTeam2OverRuns() { return team2OverRuns; }
    public void setTeam2OverRuns(List<OverRunStats> team2OverRuns) { this.team2OverRuns = team2OverRuns; }

    public List<CumulativeOverStats> getTeam1Worm() { return team1Worm; }
    public void setTeam1Worm(List<CumulativeOverStats> team1Worm) { this.team1Worm = team1Worm; }

    public List<CumulativeOverStats> getTeam2Worm() { return team2Worm; }
    public void setTeam2Worm(List<CumulativeOverStats> team2Worm) { this.team2Worm = team2Worm; }
}
