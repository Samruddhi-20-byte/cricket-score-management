package com.cricket.score.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "innings")
public class Inning {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "match_id", nullable = false)
    private Match match;

    private int inningNumber; // 1 or 2

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "batting_team_id")
    private Team battingTeam;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "bowling_team_id")
    private Team bowlingTeam;

    private int totalRuns = 0;
    private int wickets = 0;
    private int completedOvers = 0;
    private int ballsInCurrentOver = 0;

    private int wides = 0;
    private int noBalls = 0;
    private int byes = 0;
    private int legByes = 0;

    @Enumerated(EnumType.STRING)
    private InningStatus status = InningStatus.YET_TO_BAT;

    private Long currentStrikerId;
    private Long currentNonStrikerId;
    private Long currentBowlerId;

    private Integer targetRuns; // for second innings

    @OneToMany(mappedBy = "inning", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    @OrderBy("battingPosition ASC")
    private List<BattingRecord> battingRecords = new ArrayList<>();

    @OneToMany(mappedBy = "inning", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    @OrderBy("bowlingPosition ASC")
    private List<BowlingRecord> bowlingRecords = new ArrayList<>();

    @OneToMany(mappedBy = "inning", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    @OrderBy("id ASC")
    private List<BallDelivery> deliveries = new ArrayList<>();

    public Inning() {}

    public Inning(Match match, int inningNumber, Team battingTeam, Team bowlingTeam) {
        this.match = match;
        this.inningNumber = inningNumber;
        this.battingTeam = battingTeam;
        this.bowlingTeam = bowlingTeam;
    }

    public int getTotalExtras() {
        return wides + noBalls + byes + legByes;
    }

    public double getOversFormatted() {
        return completedOvers + (ballsInCurrentOver * 0.1);
    }

    public int getTotalLegalBalls() {
        return (completedOvers * 6) + ballsInCurrentOver;
    }

    public double getCurrentRunRate() {
        int totalBalls = getTotalLegalBalls();
        if (totalBalls == 0) return 0.0;
        double overs = totalBalls / 6.0;
        return Math.round((totalRuns / overs) * 100.0) / 100.0;
    }

    public Double getRequiredRunRate(int maxOvers) {
        if (targetRuns == null) return null;
        int remainingRuns = targetRuns - totalRuns;
        int totalBallsInMatch = maxOvers * 6;
        int ballsRemaining = totalBallsInMatch - getTotalLegalBalls();

        if (ballsRemaining <= 0) {
            return remainingRuns > 0 ? 99.99 : 0.0;
        }
        if (remainingRuns <= 0) return 0.0;

        double oversRemaining = ballsRemaining / 6.0;
        return Math.round((remainingRuns / oversRemaining) * 100.0) / 100.0;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Match getMatch() {
        return match;
    }

    public void setMatch(Match match) {
        this.match = match;
    }

    public int getInningNumber() {
        return inningNumber;
    }

    public void setInningNumber(int inningNumber) {
        this.inningNumber = inningNumber;
    }

    public Team getBattingTeam() {
        return battingTeam;
    }

    public void setBattingTeam(Team battingTeam) {
        this.battingTeam = battingTeam;
    }

    public Team getBowlingTeam() {
        return bowlingTeam;
    }

    public void setBowlingTeam(Team bowlingTeam) {
        this.bowlingTeam = bowlingTeam;
    }

    public int getTotalRuns() {
        return totalRuns;
    }

    public void setTotalRuns(int totalRuns) {
        this.totalRuns = totalRuns;
    }

    public int getWickets() {
        return wickets;
    }

    public void setWickets(int wickets) {
        this.wickets = wickets;
    }

    public int getCompletedOvers() {
        return completedOvers;
    }

    public void setCompletedOvers(int completedOvers) {
        this.completedOvers = completedOvers;
    }

    public int getBallsInCurrentOver() {
        return ballsInCurrentOver;
    }

    public void setBallsInCurrentOver(int ballsInCurrentOver) {
        this.ballsInCurrentOver = ballsInCurrentOver;
    }

    public int getWides() {
        return wides;
    }

    public void setWides(int wides) {
        this.wides = wides;
    }

    public int getNoBalls() {
        return noBalls;
    }

    public void setNoBalls(int noBalls) {
        this.noBalls = noBalls;
    }

    public int getByes() {
        return byes;
    }

    public void setByes(int byes) {
        this.byes = byes;
    }

    public int getLegByes() {
        return legByes;
    }

    public void setLegByes(int legByes) {
        this.legByes = legByes;
    }

    public InningStatus getStatus() {
        return status;
    }

    public void setStatus(InningStatus status) {
        this.status = status;
    }

    public Long getCurrentStrikerId() {
        return currentStrikerId;
    }

    public void setCurrentStrikerId(Long currentStrikerId) {
        this.currentStrikerId = currentStrikerId;
    }

    public Long getCurrentNonStrikerId() {
        return currentNonStrikerId;
    }

    public void setCurrentNonStrikerId(Long currentNonStrikerId) {
        this.currentNonStrikerId = currentNonStrikerId;
    }

    public Long getCurrentBowlerId() {
        return currentBowlerId;
    }

    public void setCurrentBowlerId(Long currentBowlerId) {
        this.currentBowlerId = currentBowlerId;
    }

    public Integer getTargetRuns() {
        return targetRuns;
    }

    public void setTargetRuns(Integer targetRuns) {
        this.targetRuns = targetRuns;
    }

    public List<BattingRecord> getBattingRecords() {
        return battingRecords;
    }

    public void setBattingRecords(List<BattingRecord> battingRecords) {
        this.battingRecords = battingRecords;
    }

    public List<BowlingRecord> getBowlingRecords() {
        return bowlingRecords;
    }

    public void setBowlingRecords(List<BowlingRecord> bowlingRecords) {
        this.bowlingRecords = bowlingRecords;
    }

    public List<BallDelivery> getDeliveries() {
        return deliveries;
    }

    public void setDeliveries(List<BallDelivery> deliveries) {
        this.deliveries = deliveries;
    }
}
