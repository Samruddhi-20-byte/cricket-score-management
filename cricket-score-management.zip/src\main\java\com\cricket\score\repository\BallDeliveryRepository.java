package com.cricket.score.repository;

import com.cricket.score.model.BallDelivery;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface BallDeliveryRepository extends JpaRepository<BallDelivery, Long> {
    List<BallDelivery> findByInningIdOrderByIdAsc(Long inningId);
    Page<BallDelivery> findByInningIdOrderByIdDesc(Long inningId, Pageable pageable);
    List<BallDelivery> findTop12ByInningIdOrderByIdDesc(Long inningId);
}
