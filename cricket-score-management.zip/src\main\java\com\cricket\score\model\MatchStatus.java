package com.cricket.score.model;

public enum MatchStatus {
    SCHEDULED,
    LIVE,
    INNINGS_BREAK,
    COMPLETED,
    PAUSED
}
