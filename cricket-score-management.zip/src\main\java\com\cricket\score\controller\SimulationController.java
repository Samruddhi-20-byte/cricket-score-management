package com.cricket.score.controller;

import com.cricket.score.dto.SimulationControlRequest;
import com.cricket.score.service.MatchSimulationEngine;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/matches/{id}/simulation")
public class SimulationController {

    private final MatchSimulationEngine simulationEngine;

    public SimulationController(MatchSimulationEngine simulationEngine) {
        this.simulationEngine = simulationEngine;
    }

    @PostMapping("/control")
    public ResponseEntity<Map<String, Object>> controlSimulation(
            @PathVariable Long id,
            @RequestBody SimulationControlRequest request
    ) {
        String action = request.getAction() != null ? request.getAction().toUpperCase() : "";
        int speed = request.getSpeed() != null ? request.getSpeed() : 1;

        switch (action) {
            case "START", "RESUME" -> simulationEngine.startSimulation(id, speed);
            case "PAUSE" -> simulationEngine.pauseSimulation(id);
            case "STEP" -> simulationEngine.stepSimulation(id);
            case "RESET" -> simulationEngine.resetMatch(id);
            case "SET_SPEED" -> simulationEngine.setSpeed(id, speed);
            default -> {
                return ResponseEntity.badRequest().body(Map.of("error", "Unknown action: " + action));
            }
        }

        return ResponseEntity.ok(Map.of(
                "matchId", id,
                "action", action,
                "speed", speed,
                "status", "success"
        ));
    }

    @PostMapping("/start")
    public ResponseEntity<Map<String, Object>> startSimulation(
            @PathVariable Long id,
            @RequestParam(defaultValue = "1") int speed
    ) {
        simulationEngine.startSimulation(id, speed);
        return ResponseEntity.ok(Map.of("matchId", id, "status", "started", "speed", speed));
    }

    @PostMapping("/pause")
    public ResponseEntity<Map<String, Object>> pauseSimulation(@PathVariable Long id) {
        simulationEngine.pauseSimulation(id);
        return ResponseEntity.ok(Map.of("matchId", id, "status", "paused"));
    }

    @PostMapping("/step")
    public ResponseEntity<Map<String, Object>> stepSimulation(@PathVariable Long id) {
        simulationEngine.stepSimulation(id);
        return ResponseEntity.ok(Map.of("matchId", id, "status", "stepped"));
    }

    @PostMapping("/reset")
    public ResponseEntity<Map<String, Object>> resetSimulation(@PathVariable Long id) {
        simulationEngine.resetMatch(id);
        return ResponseEntity.ok(Map.of("matchId", id, "status", "reset"));
    }

    @PostMapping("/speed")
    public ResponseEntity<Map<String, Object>> setSpeed(
            @PathVariable Long id,
            @RequestParam(defaultValue = "1") int speed
    ) {
        simulationEngine.setSpeed(id, speed);
        return ResponseEntity.ok(Map.of("matchId", id, "status", "speed_updated", "speed", speed));
    }
}
