// CricPulse Pro Chart Manager with Glow Gradients and Broadcast Visuals
class CricketChartManager {
    constructor() {
        this.wormChart = null;
        this.manhattanChart = null;
    }

    renderWormChart(canvasId, team1Name, team2Name, team1Data, team2Data) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return;

        if (this.wormChart) {
            this.wormChart.destroy();
        }

        const maxOvers = Math.max(
            team1Data.length > 0 ? team1Data[team1Data.length - 1].over : 0,
            team2Data.length > 0 ? team2Data[team2Data.length - 1].over : 0,
            20
        );

        const labels = Array.from({ length: Math.ceil(maxOvers) + 1 }, (_, i) => i);

        const t1Points = labels.map(ov => {
            const found = team1Data.find(d => Math.round(d.over) === ov);
            return found ? found.cumulativeRuns : null;
        });

        const t2Points = labels.map(ov => {
            const found = team2Data.find(d => Math.round(d.over) === ov);
            return found ? found.cumulativeRuns : null;
        });

        const chartCtx = ctx.getContext('2d');
        const gradientT1 = chartCtx.createLinearGradient(0, 0, 0, 300);
        gradientT1.addColorStop(0, 'rgba(59, 130, 246, 0.45)');
        gradientT1.addColorStop(1, 'rgba(59, 130, 246, 0.0)');

        const gradientT2 = chartCtx.createLinearGradient(0, 0, 0, 300);
        gradientT2.addColorStop(0, 'rgba(245, 158, 11, 0.45)');
        gradientT2.addColorStop(1, 'rgba(245, 158, 11, 0.0)');

        this.wormChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: team1Name || 'Team 1',
                        data: t1Points,
                        borderColor: '#60A5FA',
                        backgroundColor: gradientT1,
                        borderWidth: 3.5,
                        fill: true,
                        tension: 0.35,
                        pointRadius: 4,
                        pointBackgroundColor: '#60A5FA',
                        pointBorderColor: '#0E1626',
                        pointBorderWidth: 2,
                        pointHoverRadius: 7,
                        spanGaps: true
                    },
                    {
                        label: team2Name || 'Team 2',
                        data: t2Points,
                        borderColor: '#FBBF24',
                        backgroundColor: gradientT2,
                        borderWidth: 3.5,
                        fill: true,
                        tension: 0.35,
                        pointRadius: 4,
                        pointBackgroundColor: '#FBBF24',
                        pointBorderColor: '#0E1626',
                        pointBorderWidth: 2,
                        pointHoverRadius: 7,
                        spanGaps: true
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: {
                    duration: 750,
                    easing: 'easeOutQuart'
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            color: '#F8FAFC',
                            font: { family: 'Plus Jakarta Sans', weight: 700, size: 12 },
                            usePointStyle: true,
                            pointStyle: 'circle'
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(14, 22, 38, 0.95)',
                        titleColor: '#F8FAFC',
                        bodyColor: '#E2E8F0',
                        borderColor: 'rgba(255, 255, 255, 0.15)',
                        borderWidth: 1,
                        padding: 12,
                        boxPadding: 6,
                        titleFont: { family: 'Plus Jakarta Sans', weight: 800 },
                        bodyFont: { family: 'JetBrains Mono', weight: 600 }
                    }
                },
                scales: {
                    x: {
                        title: { display: true, text: 'Overs Bowled', color: '#94A3B8', font: { weight: 600 } },
                        grid: { color: 'rgba(255, 255, 255, 0.05)' },
                        ticks: { color: '#94A3B8' }
                    },
                    y: {
                        title: { display: true, text: 'Cumulative Runs', color: '#94A3B8', font: { weight: 600 } },
                        grid: { color: 'rgba(255, 255, 255, 0.05)' },
                        ticks: { color: '#94A3B8' }
                    }
                }
            }
        });
    }

    renderManhattanChart(canvasId, team1Name, team2Name, team1OverRuns, team2OverRuns) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return;

        if (this.manhattanChart) {
            this.manhattanChart.destroy();
        }

        const maxOvers = Math.max(
            team1OverRuns.length,
            team2OverRuns.length,
            20
        );

        const labels = Array.from({ length: maxOvers }, (_, i) => `Ov ${i + 1}`);

        const t1Data = labels.map((_, i) => {
            const found = team1OverRuns.find(o => o.overNumber === (i + 1));
            return found ? found.runs : 0;
        });

        const t2Data = labels.map((_, i) => {
            const found = team2OverRuns.find(o => o.overNumber === (i + 1));
            return found ? found.runs : 0;
        });

        this.manhattanChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: team1Name || 'Team 1',
                        data: t1Data,
                        backgroundColor: 'rgba(59, 130, 246, 0.85)',
                        hoverBackgroundColor: '#60A5FA',
                        borderColor: '#3B82F6',
                        borderWidth: 1,
                        borderRadius: 6
                    },
                    {
                        label: team2Name || 'Team 2',
                        data: t2Data,
                        backgroundColor: 'rgba(245, 158, 11, 0.85)',
                        hoverBackgroundColor: '#FBBF24',
                        borderColor: '#F59E0B',
                        borderWidth: 1,
                        borderRadius: 6
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: {
                    duration: 600,
                    easing: 'easeOutQuart'
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            color: '#F8FAFC',
                            font: { family: 'Plus Jakarta Sans', weight: 700, size: 12 },
                            usePointStyle: true,
                            pointStyle: 'rectRounded'
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(14, 22, 38, 0.95)',
                        titleColor: '#F8FAFC',
                        bodyColor: '#E2E8F0',
                        borderColor: 'rgba(255, 255, 255, 0.15)',
                        borderWidth: 1,
                        padding: 12,
                        boxPadding: 6,
                        titleFont: { family: 'Plus Jakarta Sans', weight: 800 },
                        bodyFont: { family: 'JetBrains Mono', weight: 600 }
                    }
                },
                scales: {
                    x: {
                        title: { display: true, text: 'Over Breakdown', color: '#94A3B8', font: { weight: 600 } },
                        grid: { display: false },
                        ticks: { color: '#94A3B8', maxRotation: 45, minRotation: 0 }
                    },
                    y: {
                        title: { display: true, text: 'Runs Scored', color: '#94A3B8', font: { weight: 600 } },
                        grid: { color: 'rgba(255, 255, 255, 0.05)' },
                        ticks: { color: '#94A3B8' }
                    }
                }
            }
        });
    }
}

window.CricketCharts = new CricketChartManager();
