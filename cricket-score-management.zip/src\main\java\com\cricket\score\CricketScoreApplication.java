package com.cricket.score;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class CricketScoreApplication {

    public static void main(String[] args) {
        SpringApplication.run(CricketScoreApplication.class, args);
    }
}
