package com.cricket.score.service;

import com.cricket.score.dto.*;
import com.cricket.score.model.*;
import com.cricket.score.repository.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class MatchService {

    private final MatchRepository matchRepository;
    private final InningRepository inningRepository;
    private final TeamRepository teamRepository;
    private final PlayerRepository playerRepository;
    private final BattingRecordRepository battingRecordRepository;
    private final BowlingRecordRepository bowlingRecordRepository;
    private final BallDeliveryRepository ballDeliveryRepository;
    private final ScoreCalculationService scoreCalculationService;
    private final WebSocketNotificationService webSocketNotificationService;

    public MatchService(
            MatchRepository matchRepository,
            InningRepository inningRepository,
            TeamRepository teamRepository,
            PlayerRepository playerRepository,
            BattingRecordRepository battingRecordRepository,
            BowlingRecordRepository bowlingRecordRepository,
            BallDeliveryRepository ballDeliveryRepository,
            ScoreCalculationService scoreCalculationService,
            WebSocketNotificationService webSocketNotificationService
    ) {
        this.matchRepository = matchRepository;
        this.inningRepository = inningRepository;
        this.teamRepository = teamRepository;
        this.playerRepository = playerRepository;
        this.battingRecordRepository = battingRecordRepository;
        this.bowlingRecordRepository = bowlingRecordRepository;
        this.ballDeliveryRepository = ballDeliveryRepository;
        this.scoreCalculationService = scoreCalculationService;
        this.webSocketNotificationService = webSocketNotificationService;
    }

    public List<MatchSummaryDto> getAllMatchSummaries() {
        return matchRepository.findAllByOrderByCreatedAtDesc().stream()
                .map(this::mapToSummaryDto)
                .collect(Collectors.toList());
    }

    public Match getMatchById(Long id) {
        return matchRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Match not found with id: " + id));
    }

    @Transactional(readOnly = true)
    public LiveScoreUpdateDto getLiveScore(Long matchId) {
        Match match = getMatchById(matchId);
        Inning inning = match.getCurrentInning();
        return mapToLiveScoreDto(match, inning, null);
    }

    @Transactional(readOnly = true)
    public ScorecardDto getScorecard(Long matchId) {
        Match match = getMatchById(matchId);
        ScorecardDto dto = new ScorecardDto();
        dto.setMatchId(match.getId());
        dto.setTitle(match.getTitle());
        dto.setVenue(match.getVenue());
        dto.setFormat(match.getFormat());
        dto.setStatus(match.getStatus());
        if (match.getTossWinner() != null) {
            dto.setTossInfo(match.getTossWinner().getName() + " won the toss and elected to " + match.getTossDecision());
        }
        dto.setResultMessage(match.getResultMessage());

        List<ScorecardDto.InningScorecardDto> inningDtos = new ArrayList<>();
        for (Inning inning : match.getInnings()) {
            ScorecardDto.InningScorecardDto innDto = new ScorecardDto.InningScorecardDto();
            innDto.setInningNumber(inning.getInningNumber());
            innDto.setBattingTeamName(inning.getBattingTeam() != null ? inning.getBattingTeam().getName() : "");
            innDto.setBowlingTeamName(inning.getBowlingTeam() != null ? inning.getBowlingTeam().getName() : "");
            innDto.setTotalRuns(inning.getTotalRuns());
            innDto.setWickets(inning.getWickets());
            innDto.setOversFormatted(String.format("%.1f", inning.getOversFormatted()));
            innDto.setRunRate(inning.getCurrentRunRate());

            innDto.setWides(inning.getWides());
            innDto.setNoBalls(inning.getNoBalls());
            innDto.setByes(inning.getByes());
            innDto.setLegByes(inning.getLegByes());
            innDto.setTotalExtras(inning.getTotalExtras());

            // Batting
            List<ScorecardDto.BatsmanScorecardDto> batList = new ArrayList<>();
            List<String> didNotBatList = new ArrayList<>();

            List<BattingRecord> bRecords = battingRecordRepository.findByInningIdOrderByBattingPositionAsc(inning.getId());
            for (BattingRecord br : bRecords) {
                if (br.isBatting() || br.isOut() || br.getBallsFaced() > 0) {
                    ScorecardDto.BatsmanScorecardDto bDto = new ScorecardDto.BatsmanScorecardDto();
                    bDto.setPlayerId(br.getPlayer().getId());
                    bDto.setName(br.getPlayer().getName());
                    bDto.setRuns(br.getRunsScored());
                    bDto.setBalls(br.getBallsFaced());
                    bDto.setFours(br.getFours());
                    bDto.setSixes(br.getSixes());
                    bDto.setStrikeRate(br.getStrikeRate());
                    bDto.setOut(br.isOut());
                    bDto.setDismissalType(br.getDismissalType());
                    bDto.setBowlerName(br.getBowlerName());
                    bDto.setFielderName(br.getFielderName());
                    bDto.setBatting(br.isBatting());
                    bDto.setOnStrike(br.isOnStrike());

                    if (br.isOut()) {
                        bDto.setDismissalDescription(formatDismissal(br));
                    } else if (br.isBatting()) {
                        bDto.setDismissalDescription("not out *");
                    } else {
                        bDto.setDismissalDescription("yet to bat");
                    }
                    batList.add(bDto);
                } else {
                    didNotBatList.add(br.getPlayer().getName());
                }
            }
            innDto.setBatting(batList);
            innDto.setDidNotBat(didNotBatList);

            // Bowling
            List<ScorecardDto.BowlerScorecardDto> bowlList = new ArrayList<>();
            List<BowlingRecord> bowlRecords = bowlingRecordRepository.findByInningIdOrderByBowlingPositionAsc(inning.getId());
            for (BowlingRecord br : bowlRecords) {
                if (br.getCompletedOvers() > 0 || br.getBallsInCurrentOver() > 0 || br.isCurrentBowler()) {
                    ScorecardDto.BowlerScorecardDto bDto = new ScorecardDto.BowlerScorecardDto();
                    bDto.setPlayerId(br.getPlayer().getId());
                    bDto.setName(br.getPlayer().getName());
                    bDto.setOvers(String.format("%.1f", br.getOversFormatted()));
                    bDto.setMaidens(br.getMaidenOvers());
                    bDto.setRuns(br.getRunsConceded());
                    bDto.setWickets(br.getWickets());
                    bDto.setEconomy(br.getEconomy());
                    bDto.setCurrentBowler(br.isCurrentBowler());
                    bowlList.add(bDto);
                }
            }
            innDto.setBowling(bowlList);

            // Fall of wickets
            List<ScorecardDto.FallOfWicketDto> fowList = new ArrayList<>();
            List<BallDelivery> deliveries = ballDeliveryRepository.findByInningIdOrderByIdAsc(inning.getId());
            int wCount = 0;
            for (BallDelivery d : deliveries) {
                if (d.isWicket()) {
                    wCount++;
                    String pName = d.getDismissedPlayer() != null ? d.getDismissedPlayer().getName() : "Batsman";
                    fowList.add(new ScorecardDto.FallOfWicketDto(wCount, d.getTotalInningRunsAtBall(), d.getOverString(), pName));
                }
            }
            innDto.setFallOfWickets(fowList);

            inningDtos.add(innDto);
        }

        dto.setInnings(inningDtos);
        return dto;
    }

    @Transactional(readOnly = true)
    public Page<CommentaryDto> getCommentary(Long matchId, int page, int size) {
        Match match = getMatchById(matchId);
        Inning inning = match.getCurrentInning();
        if (inning == null) return Page.empty();

        return ballDeliveryRepository.findByInningIdOrderByIdDesc(inning.getId(), PageRequest.of(page, size))
                .map(this::mapToCommentaryDto);
    }

    @Transactional(readOnly = true)
    public AnalyticsDto getAnalytics(Long matchId) {
        Match match = getMatchById(matchId);
        AnalyticsDto analytics = new AnalyticsDto();
        analytics.setMatchId(match.getId());
        analytics.setMatchTitle(match.getTitle());

        List<Inning> innings = match.getInnings();
        if (!innings.isEmpty()) {
            Inning inn1 = innings.get(0);
            populateInningAnalytics(inn1, analytics.getTeam1OverRuns(), analytics.getTeam1Worm());
        }
        if (innings.size() > 1) {
            Inning inn2 = innings.get(1);
            populateInningAnalytics(inn2, analytics.getTeam2OverRuns(), analytics.getTeam2Worm());
        }

        return analytics;
    }

    private void populateInningAnalytics(Inning inning, List<AnalyticsDto.OverRunStats> overStats, List<AnalyticsDto.CumulativeOverStats> wormStats) {
        List<BallDelivery> deliveries = ballDeliveryRepository.findByInningIdOrderByIdAsc(inning.getId());
        if (deliveries.isEmpty()) return;

        Map<Integer, Integer> runsPerOver = new HashMap<>();
        Map<Integer, Integer> wicketsPerOver = new HashMap<>();
        int maxOverSeen = 0;

        for (BallDelivery d : deliveries) {
            int over = d.getOverNumber() + 1; // 1-indexed for display
            maxOverSeen = Math.max(maxOverSeen, over);
            runsPerOver.put(over, runsPerOver.getOrDefault(over, 0) + d.getTotalRunsOnBall());
            if (d.isWicket()) {
                wicketsPerOver.put(over, wicketsPerOver.getOrDefault(over, 0) + 1);
            }
        }

        // Manhattan data
        for (int i = 1; i <= maxOverSeen; i++) {
            overStats.add(new AnalyticsDto.OverRunStats(i, runsPerOver.getOrDefault(i, 0), wicketsPerOver.getOrDefault(i, 0)));
        }

        // Worm data: at each over end (or latest delivery)
        int runningTotal = 0;
        int runningWickets = 0;
        wormStats.add(new AnalyticsDto.CumulativeOverStats(0.0, 0, 0));

        for (int i = 1; i <= maxOverSeen; i++) {
            runningTotal += runsPerOver.getOrDefault(i, 0);
            runningWickets += wicketsPerOver.getOrDefault(i, 0);
            wormStats.add(new AnalyticsDto.CumulativeOverStats((double) i, runningTotal, runningWickets));
        }
    }

    @Transactional
    public LiveScoreUpdateDto applyBallDelivery(Long matchId, BallEventRequest request) {
        Match match = getMatchById(matchId);
        BallDelivery delivery = scoreCalculationService.processBall(match, request);
        Inning currentInning = match.getCurrentInning();

        LiveScoreUpdateDto liveUpdate = mapToLiveScoreDto(match, currentInning, delivery);
        webSocketNotificationService.notifyLiveScoreUpdate(liveUpdate);

        MatchSummaryDto summaryDto = mapToSummaryDto(match);
        webSocketNotificationService.notifyMatchSummaryUpdate(summaryDto);

        return liveUpdate;
    }

    @Transactional
    public Match createMatch(CreateMatchRequest request) {
        Team team1 = teamRepository.findByName(request.getTeam1Name())
                .orElseGet(() -> teamRepository.save(new Team(request.getTeam1Name(), request.getTeam1Short(), request.getTeam1Color(), "#ffffff")));

        Team team2 = teamRepository.findByName(request.getTeam2Name())
                .orElseGet(() -> teamRepository.save(new Team(request.getTeam2Name(), request.getTeam2Short(), request.getTeam2Color(), "#ffffff")));

        Match match = new Match();
        match.setTitle(request.getTitle());
        match.setVenue(request.getVenue());
        match.setFormat(request.getFormat() != null ? request.getFormat() : MatchFormat.T20);
        match.setMaxOvers(request.getMaxOvers() > 0 ? request.getMaxOvers() : 20);
        match.setStatus(MatchStatus.LIVE);
        match.setTeam1(team1);
        match.setTeam2(team2);

        Team tossWinner = "team2".equalsIgnoreCase(request.getTossWinnerTeam()) ? team2 : team1;
        match.setTossWinner(tossWinner);
        match.setTossDecision(request.getTossDecision() != null ? request.getTossDecision() : "bat");

        Team battingFirst = tossWinner;
        Team bowlingFirst = tossWinner.getId().equals(team1.getId()) ? team2 : team1;

        if ("bowl".equalsIgnoreCase(request.getTossDecision())) {
            Team temp = battingFirst;
            battingFirst = bowlingFirst;
            bowlingFirst = temp;
        }

        // Inning 1
        Inning inning1 = new Inning(match, 1, battingFirst, bowlingFirst);
        inning1.setStatus(InningStatus.IN_PROGRESS);
        match.addInning(inning1);

        // Inning 2
        Inning inning2 = new Inning(match, 2, bowlingFirst, battingFirst);
        inning2.setStatus(InningStatus.YET_TO_BAT);
        match.addInning(inning2);

        match.setCurrentInningIndex(0);
        match.setResultMessage("Match in progress. " + battingFirst.getName() + " batting first.");
        Match savedMatch = matchRepository.save(match);

        scoreCalculationService.ensurePlayersInitialized(savedMatch, inning1);
        return savedMatch;
    }

    private MatchSummaryDto mapToSummaryDto(Match match) {
        MatchSummaryDto dto = new MatchSummaryDto();
        dto.setId(match.getId());
        dto.setTitle(match.getTitle());
        dto.setVenue(match.getVenue());
        dto.setFormat(match.getFormat());
        dto.setStatus(match.getStatus());
        dto.setMaxOvers(match.getMaxOvers());
        dto.setResultMessage(match.getResultMessage());
        dto.setSimulationActive(match.isSimulationActive());
        dto.setSimulationSpeed(match.getSimulationSpeed());

        if (match.getTeam1() != null) {
            dto.setTeam1Name(match.getTeam1().getName());
            dto.setTeam1Short(match.getTeam1().getShortName());
            dto.setTeam1Color(match.getTeam1().getPrimaryColor());
        }
        if (match.getTeam2() != null) {
            dto.setTeam2Name(match.getTeam2().getName());
            dto.setTeam2Short(match.getTeam2().getShortName());
            dto.setTeam2Color(match.getTeam2().getPrimaryColor());
        }

        List<Inning> innings = match.getInnings();
        if (!innings.isEmpty()) {
            Inning inn1 = innings.get(0);
            dto.setTeam1Score(inn1.getTotalRuns() + "/" + inn1.getWickets() + " (" + String.format("%.1f", inn1.getOversFormatted()) + ")");
        }
        if (innings.size() > 1 && innings.get(1).getStatus() != InningStatus.YET_TO_BAT) {
            Inning inn2 = innings.get(1);
            dto.setTeam2Score(inn2.getTotalRuns() + "/" + inn2.getWickets() + " (" + String.format("%.1f", inn2.getOversFormatted()) + ")");
        }

        Inning curr = match.getCurrentInning();
        if (curr != null && curr.getBattingTeam() != null) {
            dto.setCurrentBattingTeam(curr.getBattingTeam().getName());
        }
        return dto;
    }

    public LiveScoreUpdateDto mapToLiveScoreDto(Match match, Inning inning, BallDelivery latestDelivery) {
        LiveScoreUpdateDto dto = new LiveScoreUpdateDto();
        dto.setMatchId(match.getId());
        dto.setMatchTitle(match.getTitle());
        dto.setVenue(match.getVenue());
        dto.setStatus(match.getStatus());
        dto.setResultMessage(match.getResultMessage());
        dto.setSimulationActive(match.isSimulationActive());
        dto.setSimulationSpeed(match.getSimulationSpeed());
        dto.setMaxOvers(match.getMaxOvers());

        if (inning != null) {
            dto.setCurrentInningNumber(inning.getInningNumber());
            if (inning.getBattingTeam() != null) {
                dto.setBattingTeamName(inning.getBattingTeam().getName());
                dto.setBattingTeamShort(inning.getBattingTeam().getShortName());
                dto.setBattingTeamColor(inning.getBattingTeam().getPrimaryColor());
            }
            if (inning.getBowlingTeam() != null) {
                dto.setBowlingTeamName(inning.getBowlingTeam().getName());
                dto.setBowlingTeamShort(inning.getBowlingTeam().getShortName());
                dto.setBowlingTeamColor(inning.getBowlingTeam().getPrimaryColor());
            }

            dto.setTotalRuns(inning.getTotalRuns());
            dto.setWickets(inning.getWickets());
            dto.setOversDisplay(String.format("%.1f", inning.getOversFormatted()));
            dto.setCompletedOvers(inning.getCompletedOvers());
            dto.setBallsInCurrentOver(inning.getBallsInCurrentOver());
            dto.setTargetRuns(inning.getTargetRuns());
            dto.setCurrentRunRate(inning.getCurrentRunRate());
            dto.setRequiredRunRate(inning.getRequiredRunRate(match.getMaxOvers()));

            // Striker
            if (inning.getCurrentStrikerId() != null) {
                battingRecordRepository.findByInningIdAndPlayerId(inning.getId(), inning.getCurrentStrikerId())
                        .ifPresent(br -> {
                            dto.setStrikerName(br.getPlayer().getName());
                            dto.setStrikerRuns(br.getRunsScored());
                            dto.setStrikerBalls(br.getBallsFaced());
                            dto.setStrikerFours(br.getFours());
                            dto.setStrikerSixes(br.getSixes());
                            dto.setStrikerStrikeRate(br.getStrikeRate());
                        });
            }

            // Non-Striker
            if (inning.getCurrentNonStrikerId() != null) {
                battingRecordRepository.findByInningIdAndPlayerId(inning.getId(), inning.getCurrentNonStrikerId())
                        .ifPresent(br -> {
                            dto.setNonStrikerName(br.getPlayer().getName());
                            dto.setNonStrikerRuns(br.getRunsScored());
                            dto.setNonStrikerBalls(br.getBallsFaced());
                            dto.setNonStrikerFours(br.getFours());
                            dto.setNonStrikerSixes(br.getSixes());
                            dto.setNonStrikerStrikeRate(br.getStrikeRate());
                        });
            }

            // Bowler
            if (inning.getCurrentBowlerId() != null) {
                bowlingRecordRepository.findByInningIdAndPlayerId(inning.getId(), inning.getCurrentBowlerId())
                        .ifPresent(br -> {
                            dto.setBowlerName(br.getPlayer().getName());
                            dto.setBowlerOvers(String.format("%.1f", br.getOversFormatted()));
                            dto.setBowlerMaidens(br.getMaidenOvers());
                            dto.setBowlerRuns(br.getRunsConceded());
                            dto.setBowlerWickets(br.getWickets());
                            dto.setBowlerEconomy(br.getEconomy());
                        });
            }

            // Recent deliveries (last 12 balls)
            List<BallDelivery> recent = ballDeliveryRepository.findTop12ByInningIdOrderByIdDesc(inning.getId());
            Collections.reverse(recent);
            List<String> ballChips = recent.stream().map(d -> {
                if (d.isWicket()) return "W";
                if (d.getExtraType() == ExtraType.WIDE) return "Wd";
                if (d.getExtraType() == ExtraType.NO_BALL) return "Nb";
                if (d.getRunsOffBat() == 0 && d.getExtraRuns() == 0) return "•";
                return String.valueOf(d.getTotalRunsOnBall());
            }).collect(Collectors.toList());
            dto.setRecentDeliveries(ballChips);
        }

        if (latestDelivery != null) {
            dto.setLastBallCommentary(latestDelivery.getCommentary());
            dto.setFour(latestDelivery.getRunsOffBat() == 4);
            dto.setSix(latestDelivery.getRunsOffBat() == 6);
            dto.setWicket(latestDelivery.isWicket());
            dto.setExtra(latestDelivery.getExtraType() != ExtraType.NONE);
            dto.setExtraType(latestDelivery.getExtraType());

            String outcome = String.valueOf(latestDelivery.getTotalRunsOnBall());
            if (latestDelivery.isWicket()) outcome = "W";
            else if (latestDelivery.getExtraType() == ExtraType.WIDE) outcome = "Wd";
            else if (latestDelivery.getExtraType() == ExtraType.NO_BALL) outcome = "Nb";
            else if (latestDelivery.getRunsOffBat() == 0) outcome = "0";
            dto.setLastBallDisplay(outcome);
        }

        return dto;
    }

    private CommentaryDto mapToCommentaryDto(BallDelivery delivery) {
        CommentaryDto dto = new CommentaryDto();
        dto.setId(delivery.getId());
        dto.setInningNumber(delivery.getInning().getInningNumber());
        dto.setOverString(delivery.getOverString());
        dto.setOverNumber(delivery.getOverNumber());
        dto.setBallNumber(delivery.getBallNumberInOver());
        dto.setStrikerName(delivery.getStriker() != null ? delivery.getStriker().getName() : "");
        dto.setNonStrikerName(delivery.getNonStriker() != null ? delivery.getNonStriker().getName() : "");
        dto.setBowlerName(delivery.getBowler() != null ? delivery.getBowler().getName() : "");
        dto.setRunsOffBat(delivery.getRunsOffBat());
        dto.setExtraRuns(delivery.getExtraRuns());
        dto.setExtraType(delivery.getExtraType());
        dto.setWicket(delivery.isWicket());
        dto.setDismissalType(delivery.getDismissalType());
        dto.setDismissedPlayerName(delivery.getDismissedPlayer() != null ? delivery.getDismissedPlayer().getName() : null);
        dto.setTotalRuns(delivery.getTotalInningRunsAtBall());
        dto.setTotalWickets(delivery.getTotalInningWicketsAtBall());
        dto.setCommentary(delivery.getCommentary());
        dto.setTimestamp(delivery.getTimestamp());
        return dto;
    }

    private String formatDismissal(BattingRecord br) {
        return switch (br.getDismissalType()) {
            case BOWLED -> "b " + br.getBowlerName();
            case CAUGHT -> "c " + (br.getFielderName() != null ? br.getFielderName() : "sub") + " b " + br.getBowlerName();
            case LBW -> "lbw b " + br.getBowlerName();
            case RUN_OUT -> "run out (" + (br.getFielderName() != null ? br.getFielderName() : "fielder") + ")";
            case STUMPED -> "st †keeper b " + br.getBowlerName();
            default -> "out";
        };
    }
}
