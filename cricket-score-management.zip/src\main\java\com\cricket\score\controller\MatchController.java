package com.cricket.score.controller;

import com.cricket.score.dto.*;
import com.cricket.score.model.Match;
import com.cricket.score.service.MatchService;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/matches")
public class MatchController {

    private final MatchService matchService;

    public MatchController(MatchService matchService) {
        this.matchService = matchService;
    }

    @GetMapping
    public ResponseEntity<List<MatchSummaryDto>> getAllMatches() {
        return ResponseEntity.ok(matchService.getAllMatchSummaries());
    }

    @GetMapping("/{id}")
    public ResponseEntity<LiveScoreUpdateDto> getLiveScore(@PathVariable Long id) {
        return ResponseEntity.ok(matchService.getLiveScore(id));
    }

    @GetMapping("/{id}/scorecard")
    public ResponseEntity<ScorecardDto> getScorecard(@PathVariable Long id) {
        return ResponseEntity.ok(matchService.getScorecard(id));
    }

    @GetMapping("/{id}/commentary")
    public ResponseEntity<Page<CommentaryDto>> getCommentary(
            @PathVariable Long id,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "25") int size
    ) {
        return ResponseEntity.ok(matchService.getCommentary(id, page, size));
    }

    @GetMapping("/{id}/analytics")
    public ResponseEntity<AnalyticsDto> getAnalytics(@PathVariable Long id) {
        return ResponseEntity.ok(matchService.getAnalytics(id));
    }

    @PostMapping
    public ResponseEntity<Match> createMatch(@RequestBody CreateMatchRequest request) {
        Match match = matchService.createMatch(request);
        return new ResponseEntity<>(match, HttpStatus.CREATED);
    }

    @PostMapping("/{id}/balls")
    public ResponseEntity<LiveScoreUpdateDto> applyBallDelivery(
            @PathVariable Long id,
            @RequestBody BallEventRequest request
    ) {
        LiveScoreUpdateDto update = matchService.applyBallDelivery(id, request);
        return ResponseEntity.ok(update);
    }
}
