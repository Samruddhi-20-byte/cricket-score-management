package com.cricket.score.service;

import com.cricket.score.dto.BallEventRequest;
import com.cricket.score.model.*;
import com.cricket.score.repository.BallDeliveryRepository;
import com.cricket.score.repository.BattingRecordRepository;
import com.cricket.score.repository.BowlingRecordRepository;
import com.cricket.score.repository.InningRepository;
import com.cricket.score.repository.MatchRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ScoreCalculationService {

    private final MatchRepository matchRepository;
    private final InningRepository inningRepository;
    private final BattingRecordRepository battingRecordRepository;
    private final BowlingRecordRepository bowlingRecordRepository;
    private final BallDeliveryRepository ballDeliveryRepository;

    public ScoreCalculationService(
            MatchRepository matchRepository,
            InningRepository inningRepository,
            BattingRecordRepository battingRecordRepository,
            BowlingRecordRepository bowlingRecordRepository,
            BallDeliveryRepository ballDeliveryRepository
    ) {
        this.matchRepository = matchRepository;
        this.inningRepository = inningRepository;
        this.battingRecordRepository = battingRecordRepository;
        this.bowlingRecordRepository = bowlingRecordRepository;
        this.ballDeliveryRepository = ballDeliveryRepository;
    }

    @Transactional
    public BallDelivery processBall(Match match, BallEventRequest request) {
        Inning inning = match.getCurrentInning();
        if (inning == null || inning.getStatus() == InningStatus.COMPLETED) {
            throw new IllegalStateException("Current inning is not active or match has ended.");
        }

        if (inning.getStatus() == InningStatus.YET_TO_BAT) {
            inning.setStatus(InningStatus.IN_PROGRESS);
            match.setStatus(MatchStatus.LIVE);
        }

        // Initialize players at crease if not already set
        ensurePlayersInitialized(match, inning);

        // Fetch current striker, non-striker, bowler records
        BattingRecord strikerRecord = getOrCreateBattingRecord(inning, inning.getCurrentStrikerId());
        BattingRecord nonStrikerRecord = getOrCreateBattingRecord(inning, inning.getCurrentNonStrikerId());
        BowlingRecord bowlerRecord = getOrCreateBowlingRecord(inning, inning.getCurrentBowlerId());

        Player striker = strikerRecord.getPlayer();
        Player nonStriker = nonStrikerRecord.getPlayer();
        Player bowler = bowlerRecord.getPlayer();

        int runsOffBat = Math.max(0, request.getRunsOffBat());
        int extraRuns = Math.max(0, request.getExtraRuns());
        ExtraType extraType = request.getExtraType() != null ? request.getExtraType() : ExtraType.NONE;
        boolean isWicket = request.isWicket();
        DismissalType dismissalType = request.getDismissalType() != null ? request.getDismissalType() : DismissalType.NOT_OUT;

        boolean isLegalDelivery = (extraType != ExtraType.WIDE && extraType != ExtraType.NO_BALL);

        // Calculate delivery totals
        int totalRunsThisBall = 0;
        int bowlerRunsConcededThisBall = 0;

        switch (extraType) {
            case WIDE -> {
                int wideRuns = 1 + extraRuns;
                totalRunsThisBall = wideRuns;
                inning.setWides(inning.getWides() + wideRuns);
                bowlerRunsConcededThisBall = wideRuns;
                // Striker does not face ball
            }
            case NO_BALL -> {
                int nbRuns = 1 + extraRuns;
                totalRunsThisBall = nbRuns + runsOffBat;
                inning.setNoBalls(inning.getNoBalls() + nbRuns);
                strikerRecord.setBallsFaced(strikerRecord.getBallsFaced() + 1);
                strikerRecord.setRunsScored(strikerRecord.getRunsScored() + runsOffBat);
                if (runsOffBat == 4) strikerRecord.setFours(strikerRecord.getFours() + 1);
                if (runsOffBat == 6) strikerRecord.setSixes(strikerRecord.getSixes() + 1);
                bowlerRunsConcededThisBall = totalRunsThisBall;
            }
            case BYE -> {
                totalRunsThisBall = extraRuns;
                inning.setByes(inning.getByes() + extraRuns);
                strikerRecord.setBallsFaced(strikerRecord.getBallsFaced() + 1);
                // Byes not charged to bowler
            }
            case LEG_BYE -> {
                totalRunsThisBall = extraRuns;
                inning.setLegByes(inning.getLegByes() + extraRuns);
                strikerRecord.setBallsFaced(strikerRecord.getBallsFaced() + 1);
                // Leg byes not charged to bowler
            }
            case PENALTY -> {
                totalRunsThisBall = extraRuns;
            }
            case NONE -> {
                totalRunsThisBall = runsOffBat;
                strikerRecord.setBallsFaced(strikerRecord.getBallsFaced() + 1);
                strikerRecord.setRunsScored(strikerRecord.getRunsScored() + runsOffBat);
                if (runsOffBat == 4) strikerRecord.setFours(strikerRecord.getFours() + 1);
                if (runsOffBat == 6) strikerRecord.setSixes(strikerRecord.getSixes() + 1);
                bowlerRunsConcededThisBall = runsOffBat;
            }
        }

        // Apply runs
        inning.setTotalRuns(inning.getTotalRuns() + totalRunsThisBall);
        bowlerRecord.setRunsConceded(bowlerRecord.getRunsConceded() + bowlerRunsConcededThisBall);

        // Handle wicket
        Player dismissedPlayer = null;
        if (isWicket) {
            inning.setWickets(inning.getWickets() + 1);
            if (dismissalType != DismissalType.RUN_OUT) {
                bowlerRecord.setWickets(bowlerRecord.getWickets() + 1);
            }

            strikerRecord.setOut(true);
            strikerRecord.setBatting(false);
            strikerRecord.setOnStrike(false);
            strikerRecord.setDismissalType(dismissalType);
            strikerRecord.setBowlerName(bowler.getName());
            dismissedPlayer = striker;

            // Pick next batsman if wickets < 10
            if (inning.getWickets() < 10) {
                Player nextBatsman = pickNextBatsman(inning);
                if (nextBatsman != null) {
                    BattingRecord newRecord = getOrCreateBattingRecord(inning, nextBatsman.getId());
                    newRecord.setBatting(true);
                    newRecord.setOnStrike(true);
                    inning.setCurrentStrikerId(nextBatsman.getId());
                }
            }
        }

        // Check strike rotation during the ball
        int runsToRotate = (extraType == ExtraType.BYE || extraType == ExtraType.LEG_BYE) ? extraRuns : runsOffBat;
        if (!isWicket && (runsToRotate % 2 != 0)) {
            swapStrike(inning, strikerRecord, nonStrikerRecord);
        }

        // Handle legal delivery ball increment & over progression
        int currentOverNumber = inning.getCompletedOvers();
        int currentBallInOver = inning.getBallsInCurrentOver();

        if (isLegalDelivery) {
            currentBallInOver++;
            bowlerRecord.setBallsInCurrentOver(bowlerRecord.getBallsInCurrentOver() + 1);

            if (currentBallInOver >= 6) {
                inning.setCompletedOvers(inning.getCompletedOvers() + 1);
                inning.setBallsInCurrentOver(0);

                bowlerRecord.setCompletedOvers(bowlerRecord.getCompletedOvers() + 1);
                bowlerRecord.setBallsInCurrentOver(0);
                bowlerRecord.setCurrentBowler(false);

                // Check for maiden over: 0 runs conceded in this full over
                // (Simplified: if this over had 0 runs conceded)
                // Swap strike at end of over
                swapStrike(inning, getOrCreateBattingRecord(inning, inning.getCurrentStrikerId()),
                        getOrCreateBattingRecord(inning, inning.getCurrentNonStrikerId()));

                // Select next bowler
                Player nextBowler = pickNextBowler(inning, bowler.getId());
                if (nextBowler != null) {
                    BowlingRecord nextBowlerRecord = getOrCreateBowlingRecord(inning, nextBowler.getId());
                    nextBowlerRecord.setCurrentBowler(true);
                    inning.setCurrentBowlerId(nextBowler.getId());
                }
            } else {
                inning.setBallsInCurrentOver(currentBallInOver);
            }
        }

        // Save delivery record
        BallDelivery delivery = new BallDelivery();
        delivery.setInning(inning);
        delivery.setOverNumber(currentOverNumber);
        delivery.setBallNumberInOver(isLegalDelivery ? currentBallInOver : Math.max(1, currentBallInOver));
        delivery.setLegalDelivery(isLegalDelivery);
        delivery.setStriker(striker);
        delivery.setNonStriker(nonStriker);
        delivery.setBowler(bowler);
        delivery.setRunsOffBat(runsOffBat);
        delivery.setExtraRuns(extraRuns);
        delivery.setExtraType(extraType);
        delivery.setWicket(isWicket);
        delivery.setDismissalType(dismissalType);
        delivery.setDismissedPlayer(dismissedPlayer);
        delivery.setTotalInningRunsAtBall(inning.getTotalRuns());
        delivery.setTotalInningWicketsAtBall(inning.getWickets());
        delivery.setCommentary(request.getCommentary() != null && !request.getCommentary().isBlank()
                ? request.getCommentary()
                : generateCommentary(striker, bowler, runsOffBat, extraType, extraRuns, isWicket, dismissalType));
        delivery.setTimestamp(LocalDateTime.now());

        ballDeliveryRepository.save(delivery);
        inning.getDeliveries().add(delivery);

        // Check match/inning end conditions
        evaluateInningAndMatchState(match, inning);

        battingRecordRepository.save(strikerRecord);
        battingRecordRepository.save(nonStrikerRecord);
        bowlingRecordRepository.save(bowlerRecord);
        inningRepository.save(inning);
        matchRepository.save(match);

        return delivery;
    }

    private void swapStrike(Inning inning, BattingRecord r1, BattingRecord r2) {
        if (r1 == null || r2 == null) return;
        Long tempStrikerId = inning.getCurrentStrikerId();
        inning.setCurrentStrikerId(inning.getCurrentNonStrikerId());
        inning.setCurrentNonStrikerId(tempStrikerId);

        r1.setOnStrike(!r1.isOnStrike());
        r2.setOnStrike(!r2.isOnStrike());
    }

    private void evaluateInningAndMatchState(Match match, Inning inning) {
        boolean isInningAllOut = inning.getWickets() >= 10;
        boolean isOversComplete = (inning.getCompletedOvers() >= match.getMaxOvers());

        if (inning.getInningNumber() == 1) {
            if (isInningAllOut || isOversComplete) {
                inning.setStatus(InningStatus.COMPLETED);
                int target = inning.getTotalRuns() + 1;

                if (match.getInnings().size() > 1) {
                    Inning secondInning = match.getInnings().get(1);
                    secondInning.setTargetRuns(target);
                    secondInning.setStatus(InningStatus.IN_PROGRESS);
                    match.setCurrentInningIndex(1);
                    ensurePlayersInitialized(match, secondInning);
                    match.setStatus(MatchStatus.LIVE);
                    match.setResultMessage(secondInning.getBattingTeam().getName() + " need " + target + " runs to win.");
                } else {
                    match.setStatus(MatchStatus.INNINGS_BREAK);
                    match.setResultMessage("Target: " + target + " runs.");
                }
            }
        } else if (inning.getInningNumber() == 2) {
            Integer target = inning.getTargetRuns();
            if (target != null && inning.getTotalRuns() >= target) {
                // Target reached! Batting team won
                inning.setStatus(InningStatus.COMPLETED);
                match.setStatus(MatchStatus.COMPLETED);
                match.setWinner(inning.getBattingTeam());
                int wicketsLeft = 10 - inning.getWickets();
                match.setResultMessage(inning.getBattingTeam().getName() + " won by " + wicketsLeft + " wicket" + (wicketsLeft > 1 ? "s" : "") + "!");
                match.setSimulationActive(false);
            } else if (isInningAllOut || isOversComplete) {
                // Inning ended without reaching target
                inning.setStatus(InningStatus.COMPLETED);
                match.setStatus(MatchStatus.COMPLETED);
                if (target != null) {
                    if (inning.getTotalRuns() == target - 1) {
                        match.setResultMessage("Match Tied! Super Over required!");
                    } else {
                        match.setWinner(inning.getBowlingTeam());
                        int margin = (target - 1) - inning.getTotalRuns();
                        match.setResultMessage(inning.getBowlingTeam().getName() + " won by " + margin + " run" + (margin > 1 ? "s" : "") + "!");
                    }
                }
                match.setSimulationActive(false);
            } else if (target != null) {
                int runsNeeded = target - inning.getTotalRuns();
                int ballsRemaining = (match.getMaxOvers() * 6) - inning.getTotalLegalBalls();
                match.setResultMessage(inning.getBattingTeam().getShortName() + " need " + runsNeeded + " runs in " + ballsRemaining + " balls.");
            }
        }
    }

    public void ensurePlayersInitialized(Match match, Inning inning) {
        Team battingTeam = inning.getBattingTeam();
        Team bowlingTeam = inning.getBowlingTeam();

        if (inning.getBattingRecords().isEmpty() && battingTeam != null && !battingTeam.getPlayers().isEmpty()) {
            List<Player> players = battingTeam.getPlayers();
            for (int i = 0; i < players.size(); i++) {
                Player p = players.get(i);
                BattingRecord record = new BattingRecord(p, inning, i + 1);
                if (i == 0) {
                    record.setBatting(true);
                    record.setOnStrike(true);
                    inning.setCurrentStrikerId(p.getId());
                } else if (i == 1) {
                    record.setBatting(true);
                    record.setOnStrike(false);
                    inning.setCurrentNonStrikerId(p.getId());
                }
                battingRecordRepository.save(record);
                inning.getBattingRecords().add(record);
            }
        }

        if (inning.getBowlingRecords().isEmpty() && bowlingTeam != null && !bowlingTeam.getPlayers().isEmpty()) {
            List<Player> players = bowlingTeam.getPlayers();
            // Typically bowlers are lower in the list or have BOWLER/ALL_ROUNDER role
            int bowlingPos = 1;
            for (int i = players.size() - 1; i >= 0; i--) {
                Player p = players.get(i);
                if (p.getRole() == PlayerRole.BOWLER || p.getRole() == PlayerRole.ALL_ROUNDER || bowlingPos <= 5) {
                    BowlingRecord record = new BowlingRecord(p, inning, bowlingPos++);
                    if (bowlingPos == 2) { // First bowler picked
                        record.setCurrentBowler(true);
                        inning.setCurrentBowlerId(p.getId());
                    }
                    bowlingRecordRepository.save(record);
                    inning.getBowlingRecords().add(record);
                }
            }
            if (inning.getCurrentBowlerId() == null && !inning.getBowlingRecords().isEmpty()) {
                inning.setCurrentBowlerId(inning.getBowlingRecords().get(0).getPlayer().getId());
                inning.getBowlingRecords().get(0).setCurrentBowler(true);
            }
        }
    }

    public BattingRecord getOrCreateBattingRecord(Inning inning, Long playerId) {
        if (playerId == null) return null;
        Optional<BattingRecord> opt = battingRecordRepository.findByInningIdAndPlayerId(inning.getId(), playerId);
        if (opt.isPresent()) return opt.get();

        // Find player in batting team
        Player player = inning.getBattingTeam().getPlayers().stream()
                .filter(p -> p.getId().equals(playerId))
                .findFirst()
                .orElse(null);

        if (player == null) return null;
        BattingRecord record = new BattingRecord(player, inning, inning.getBattingRecords().size() + 1);
        return battingRecordRepository.save(record);
    }

    public BowlingRecord getOrCreateBowlingRecord(Inning inning, Long playerId) {
        if (playerId == null) return null;
        Optional<BowlingRecord> opt = bowlingRecordRepository.findByInningIdAndPlayerId(inning.getId(), playerId);
        if (opt.isPresent()) return opt.get();

        Player player = inning.getBowlingTeam().getPlayers().stream()
                .filter(p -> p.getId().equals(playerId))
                .findFirst()
                .orElse(null);

        if (player == null) return null;
        BowlingRecord record = new BowlingRecord(player, inning, inning.getBowlingRecords().size() + 1);
        return bowlingRecordRepository.save(record);
    }

    private Player pickNextBatsman(Inning inning) {
        List<Player> players = inning.getBattingTeam().getPlayers();
        for (Player p : players) {
            Optional<BattingRecord> rec = battingRecordRepository.findByInningIdAndPlayerId(inning.getId(), p.getId());
            if (rec.isEmpty() || (!rec.get().isOut() && !rec.get().isBatting())) {
                return p;
            }
        }
        return null;
    }

    private Player pickNextBowler(Inning inning, Long currentBowlerId) {
        List<BowlingRecord> bowlers = inning.getBowlingRecords();
        if (bowlers.isEmpty()) return null;
        for (BowlingRecord br : bowlers) {
            if (!br.getPlayer().getId().equals(currentBowlerId)) {
                return br.getPlayer();
            }
        }
        return bowlers.get(0).getPlayer();
    }

    private String generateCommentary(Player striker, Player bowler, int runs, ExtraType extraType, int extraRuns, boolean isWicket, DismissalType dismissal) {
        String sName = striker != null ? striker.getName() : "Striker";
        String bName = bowler != null ? bowler.getName() : "Bowler";

        if (isWicket) {
            return switch (dismissal) {
                case BOWLED -> bName + " to " + sName + ", OUT! CLEAN BOWLED! Absolute corker that beats the inside edge and crashes into off stump!";
                case CAUGHT -> bName + " to " + sName + ", OUT! CAUGHT! Spliced high in the air and taken safely by the fielder!";
                case LBW -> bName + " to " + sName + ", OUT! LBW! Trapped right in front of middle stump, umpire raises the finger immediately!";
                case RUN_OUT -> bName + " to " + sName + ", OUT! RUN OUT! Direct hit! The batsman was well short of the crease!";
                case STUMPED -> bName + " to " + sName + ", OUT! STUMPED! Dragged out of the crease, lightning-fast glovework behind the stumps!";
                default -> bName + " to " + sName + ", OUT! Wicket falls!";
            };
        }

        if (extraType == ExtraType.WIDE) {
            return bName + " to " + sName + ", WIDE! Sprayed well outside off stump, umpire signals extra run.";
        }
        if (extraType == ExtraType.NO_BALL) {
            return bName + " to " + sName + ", NO BALL! Overstepped the front line! Free hit coming up!";
        }

        return switch (runs) {
            case 6 -> bName + " to " + sName + ", SIX! HIGH, HANDSOME AND INTO THE STANDS! Colossal strike over deep mid-wicket!";
            case 4 -> bName + " to " + sName + ", FOUR! Pure timing! Leans into the drive and drills it through cover point!";
            case 3 -> bName + " to " + sName + ", 3 runs. Placed into the vacant pocket in the deep, excellent running between the wickets!";
            case 2 -> bName + " to " + sName + ", 2 runs. Clipped off the pads towards deep square leg, easy brace taken.";
            case 1 -> bName + " to " + sName + ", 1 run. Pushed down to long-on for a single to rotate the strike.";
            default -> bName + " to " + sName + ", no run. Good length ball on off stump, solidly defended back to the bowler.";
        };
    }
}
