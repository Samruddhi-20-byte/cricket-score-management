// CricPulse Pro Application Controller
const App = {
    activeMatchId: null,
    matches: [],
    activeTab: 'commentary',
    isSimulationRunning: false,
    currentSpeed: 1,
    lastRuns: 0,
    lastWickets: 0,

    async init() {
        this.setupParticles();
        this.setupEventListeners();
        this.setupWebSocket();
        await this.loadMatches();

        if (this.matches.length > 0) {
            this.selectMatch(this.matches[0].id);
        }
    },

    setupParticles() {
        const canvas = document.getElementById('confetti-canvas');
        if (!canvas) return;
        this.ctx = canvas.getContext('2d');
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        window.addEventListener('resize', () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        });
        this.particles = [];
        this.animateParticles();
    },

    burstParticles(x, y, colorScheme = 'gold') {
        const colors = colorScheme === 'boundary' 
            ? ['#10B981', '#34D399', '#6EE7B7', '#FFFFFF']
            : colorScheme === 'six'
            ? ['#A855F7', '#C084FC', '#F43F5E', '#FBBF24', '#FFFFFF']
            : ['#F43F5E', '#FB7185', '#E11D48', '#FFAA00'];

        for (let i = 0; i < 45; i++) {
            const angle = Math.random() * Math.PI * 2;
            const speed = Math.random() * 8 + 3;
            this.particles.push({
                x: x || window.innerWidth / 2,
                y: y || 250,
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed - 2,
                size: Math.random() * 6 + 4,
                color: colors[Math.floor(Math.random() * colors.length)],
                alpha: 1,
                decay: Math.random() * 0.02 + 0.015,
                rotation: Math.random() * 360,
                vRot: (Math.random() - 0.5) * 10
            });
        }
    },

    animateParticles() {
        if (this.ctx) {
            this.ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
            for (let i = this.particles.length - 1; i >= 0; i--) {
                const p = this.particles[i];
                p.x += p.vx;
                p.y += p.vy;
                p.vy += 0.2; // gravity
                p.alpha -= p.decay;
                p.rotation += p.vRot;

                if (p.alpha <= 0) {
                    this.particles.splice(i, 1);
                    continue;
                }

                this.ctx.save();
                this.ctx.globalAlpha = p.alpha;
                this.ctx.translate(p.x, p.y);
                this.ctx.rotate((p.rotation * Math.PI) / 180);
                this.ctx.fillStyle = p.color;
                this.ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.6);
                this.ctx.restore();
            }
        }
        requestAnimationFrame(() => this.animateParticles());
    },

    setupWebSocket() {
        window.CricketWS.onConnectionChange((status) => {
            const dot = document.getElementById('ws-status-dot');
            const text = document.getElementById('ws-status-text');

            if (!dot || !text) return;

            if (status === 'connected') {
                dot.className = 'w-2.5 h-2.5 rounded-full bg-emerald-400 pulse-dot';
                text.textContent = 'LIVE FEED SYNCED';
                text.className = 'text-xs font-bold text-emerald-400';
            } else if (status === 'connecting') {
                dot.className = 'w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse';
                text.textContent = 'CONNECTING...';
                text.className = 'text-xs font-bold text-amber-400';
            } else {
                dot.className = 'w-2.5 h-2.5 rounded-full bg-rose-500';
                text.textContent = 'RECONNECTING';
                text.className = 'text-xs font-bold text-rose-400';
            }
        });

        window.CricketWS.onLiveUpdate((update) => {
            this.handleLiveUpdate(update);
        });

        window.CricketWS.onMatchSummary((summary) => {
            this.handleMatchSummary(summary);
        });

        window.CricketWS.connect();
    },

    setupEventListeners() {
        // Sound toggle
        const soundBtn = document.getElementById('sound-toggle-btn');
        if (soundBtn) {
            soundBtn.addEventListener('click', () => {
                const isEnabled = window.SoundEngine.toggle();
                soundBtn.innerHTML = isEnabled 
                    ? `<span>🔊</span> Sound FX: ON`
                    : `<span>🔇</span> Sound FX: OFF`;
                soundBtn.className = isEnabled
                    ? 'flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30 text-xs font-bold transition'
                    : 'flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gray-800 text-gray-400 border border-gray-700 text-xs font-bold transition';
            });
        }

        // Tab switching
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const tab = btn.dataset.tab;
                this.switchTab(tab);
            });
        });

        // Simulation controls
        document.getElementById('sim-play-btn')?.addEventListener('click', () => this.triggerSimulation('START'));
        document.getElementById('sim-pause-btn')?.addEventListener('click', () => this.triggerSimulation('PAUSE'));
        document.getElementById('sim-step-btn')?.addEventListener('click', () => this.triggerSimulation('STEP'));
        document.getElementById('sim-reset-btn')?.addEventListener('click', () => this.triggerSimulation('RESET'));

        document.querySelectorAll('.speed-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const speed = parseInt(btn.dataset.speed, 10);
                this.setSimulationSpeed(speed);
            });
        });

        // Quick Manual Actions
        document.querySelectorAll('.quick-ball-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const runs = parseInt(btn.dataset.runs || '0', 10);
                const extra = btn.dataset.extra || 'NONE';
                const isWicket = btn.dataset.wicket === 'true';
                const dismissal = isWicket ? 'BOWLED' : 'NOT_OUT';
                this.recordManualBall(runs, extra, isWicket, dismissal);
            });
        });

        // Create Match Modal
        document.getElementById('open-create-match-btn')?.addEventListener('click', () => {
            document.getElementById('create-match-modal')?.classList.remove('hidden');
        });
        document.getElementById('close-create-match-btn')?.addEventListener('click', () => {
            document.getElementById('create-match-modal')?.classList.add('hidden');
        });
        document.getElementById('create-match-form')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleCreateMatch();
        });
    },

    async loadMatches() {
        try {
            this.matches = await window.API.getMatches();
            this.renderMatchTicker();
        } catch (e) {
            console.error('Failed to load matches', e);
        }
    },

    renderMatchTicker() {
        const container = document.getElementById('match-ticker-container');
        if (!container) return;

        container.innerHTML = this.matches.map(m => {
            const isSelected = m.id === this.activeMatchId;
            const statusBadge = m.status === 'LIVE' 
                ? '<span class="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-red-500/20 text-red-400 border border-red-500/30 animate-pulse">● LIVE</span>'
                : m.status === 'COMPLETED'
                ? '<span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-gray-700 text-gray-300">FINAL</span>'
                : '<span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/20 text-blue-400">UPCOMING</span>';

            const team1Code = m.team1Short || m.team1Name?.substring(0, 3).toUpperCase() || 'TM1';
            const team2Code = m.team2Short || m.team2Name?.substring(0, 3).toUpperCase() || 'TM2';

            return `
                <div class="glass-card cursor-pointer rounded-2xl p-4 min-w-[300px] max-w-[340px] shrink-0 border transition-all ${isSelected ? 'border-blue-500 ring-2 ring-blue-500/30 bg-gray-800/90 shadow-lg shadow-blue-500/10' : 'border-gray-800/80 hover:border-gray-700'}"
                     onclick="App.selectMatch(${m.id})">
                    <div class="flex items-center justify-between mb-2.5">
                        ${statusBadge}
                        <span class="text-[11px] text-gray-400 font-medium truncate max-w-[140px]">${m.venue || 'International Arena'}</span>
                    </div>
                    <div class="text-xs font-bold text-gray-200 mb-2 truncate">${m.title}</div>
                    <div class="space-y-1.5 bg-gray-900/40 p-2.5 rounded-xl border border-gray-800/50">
                        <div class="flex justify-between items-center text-xs">
                            <div class="flex items-center gap-2">
                                <div class="w-2.5 h-2.5 rounded-full bg-blue-500"></div>
                                <span class="font-bold text-gray-200">${m.team1Name}</span>
                            </div>
                            <span class="font-black mono-font text-white">${m.team1Score || 'Yet to bat'}</span>
                        </div>
                        <div class="flex justify-between items-center text-xs">
                            <div class="flex items-center gap-2">
                                <div class="w-2.5 h-2.5 rounded-full bg-amber-400"></div>
                                <span class="font-bold text-gray-200">${m.team2Name}</span>
                            </div>
                            <span class="font-black mono-font text-white">${m.team2Score || 'Yet to bat'}</span>
                        </div>
                    </div>
                    <div class="mt-2.5 text-[11px] text-amber-400 font-bold truncate flex items-center gap-1.5">
                        <span class="text-blue-400">⚡</span> ${m.resultMessage || 'Match in progress'}
                    </div>
                </div>
            `;
        }).join('');
    },

    async selectMatch(matchId) {
        this.activeMatchId = matchId;
        this.renderMatchTicker();
        window.CricketWS.subscribeToMatch(matchId);

        try {
            const scoreData = await window.API.getLiveScore(matchId);
            this.lastRuns = scoreData.totalRuns;
            this.lastWickets = scoreData.wickets;

            this.updateHeroScoreboard(scoreData);
            this.updateSimulationDock(scoreData.simulationActive, scoreData.simulationSpeed);
            this.updatePitchRadar(scoreData);

            if (this.activeTab === 'commentary') this.loadCommentary();
            else if (this.activeTab === 'scorecard') this.loadScorecard();
            else if (this.activeTab === 'analytics') this.loadAnalytics();
        } catch (e) {
            console.error(`Failed to select match ${matchId}`, e);
        }
    },

    handleLiveUpdate(update) {
        if (!update || update.matchId !== this.activeMatchId) return;

        // Audio & Visual Effects Trigger
        if (update.six) {
            window.SoundEngine.playSixer();
            this.burstParticles(null, null, 'six');
            this.showEventToast('🚀 MAXIMUM! SIX RUNS!', 'Colossal strike sails deep into the upper stands!', 'bg-purple-600');
        } else if (update.four) {
            window.SoundEngine.playBoundaryFour();
            this.burstParticles(null, null, 'boundary');
            this.showEventToast('⚡ BOUNDARY! FOUR RUNS!', 'Pure timing! Pierces the boundary rope with blazing speed!', 'bg-emerald-600');
        } else if (update.wicket) {
            window.SoundEngine.playWicket();
            this.burstParticles(null, null, 'wicket');
            this.showEventToast('💥 TIMBER! WICKET FALLEN!', 'Big breakthrough! Celebrations ignite on the pitch!', 'bg-rose-600');
        } else if (update.totalRuns > this.lastRuns) {
            window.SoundEngine.playBatHit();
        }

        this.lastRuns = update.totalRuns;
        this.lastWickets = update.wickets;

        this.updateHeroScoreboard(update);
        this.updateSimulationDock(update.simulationActive, update.simulationSpeed);
        this.updatePitchRadar(update);

        // Flash hero animation
        const heroCard = document.getElementById('hero-scoreboard');
        if (heroCard) {
            heroCard.classList.remove('flash-boundary', 'flash-wicket');
            void heroCard.offsetWidth;
            if (update.four || update.six) {
                heroCard.classList.add('flash-boundary');
            } else if (update.wicket) {
                heroCard.classList.add('flash-wicket');
            }
        }

        if (update.lastBallCommentary) {
            this.prependCommentaryBall(update);
        }

        if (this.activeTab === 'scorecard') this.loadScorecard();
        else if (this.activeTab === 'analytics') this.loadAnalytics();
    },

    handleMatchSummary(summary) {
        if (!summary) return;
        const index = this.matches.findIndex(m => m.id === summary.id);
        if (index >= 0) this.matches[index] = summary;
        else this.matches.unshift(summary);
        this.renderMatchTicker();
    },

    updateHeroScoreboard(data) {
        if (!data) return;

        setText('hero-title', data.matchTitle);
        setText('hero-venue', data.venue);
        setText('hero-result-message', data.resultMessage || 'Match in progress');

        // Number animation pop
        const runsEl = document.getElementById('hero-runs');
        if (runsEl) {
            runsEl.textContent = data.totalRuns;
            runsEl.classList.remove('animate-pop');
            void runsEl.offsetWidth;
            runsEl.classList.add('animate-pop');
        }

        setText('hero-wickets', `/${data.wickets}`);
        setText('hero-overs', `(${data.oversDisplay} / ${data.maxOvers}.0 ov)`);
        setText('hero-batting-team', `${data.battingTeamName || 'Batting Team'} • 2nd Innings`);
        setText('hero-crr', data.currentRunRate ? data.currentRunRate.toFixed(2) : '0.00');

        // Required Run Rate & Target
        const rrrContainer = document.getElementById('hero-rrr-container');
        if (data.requiredRunRate != null && data.targetRuns != null) {
            if (rrrContainer) rrrContainer.style.display = 'block';
            setText('hero-target', data.targetRuns);
            setText('hero-rrr', data.requiredRunRate.toFixed(2));
            this.updateWinProbability(data);
        } else {
            if (rrrContainer) rrrContainer.style.display = 'none';
        }

        // Active Striker Card
        setText('striker-name', data.strikerName || '—');
        setText('striker-runs', data.strikerRuns ?? '0');
        setText('striker-balls', `${data.strikerBalls ?? 0}b`);
        setText('striker-boundaries', `${data.strikerFours ?? 0} fours • ${data.strikerSixes ?? 0} sixes`);
        setText('striker-sr', `${data.strikerStrikeRate ? data.strikerStrikeRate.toFixed(1) : '0.0'}`);

        // Active Non-Striker Card
        setText('non-striker-name', data.nonStrikerName || '—');
        setText('non-striker-runs', data.nonStrikerRuns ?? '0');
        setText('non-striker-balls', `${data.nonStrikerBalls ?? 0}b`);
        setText('non-striker-boundaries', `${data.nonStrikerFours ?? 0} fours • ${data.nonStrikerSixes ?? 0} sixes`);
        setText('non-striker-sr', `${data.nonStrikerStrikeRate ? data.nonStrikerStrikeRate.toFixed(1) : '0.0'}`);

        // Active Bowler Card
        setText('bowler-name', data.bowlerName || '—');
        setText('bowler-figures', `${data.bowlerWickets ?? 0}/${data.bowlerRuns ?? 0}`);
        setText('bowler-overs', `${data.bowlerOvers ?? '0.0'} ov • ${data.bowlerMaidens ?? 0} maidens`);
        setText('bowler-econ', `${data.bowlerEconomy ? data.bowlerEconomy.toFixed(2) : '0.00'}`);

        // Over Chips
        const overChipsContainer = document.getElementById('recent-over-chips');
        if (overChipsContainer && data.recentDeliveries) {
            overChipsContainer.innerHTML = data.recentDeliveries.map(chip => {
                let chipClass = 'ball-chip-single';
                if (chip === '•' || chip === '0') chipClass = 'ball-chip-dot';
                else if (chip === '4') chipClass = 'ball-chip-four';
                else if (chip === '6') chipClass = 'ball-chip-six';
                else if (chip === 'W') chipClass = 'ball-chip-wicket';
                else if (chip === 'Wd' || chip === 'Nb') chipClass = 'ball-chip-extra';

                return `<span class="ball-chip ${chipClass} digital-font">${chip}</span>`;
            }).join('');
        }
    },

    updateWinProbability(data) {
        if (!data.targetRuns) return;
        const ballsRemaining = (data.maxOvers * 6) - (data.completedOvers * 6 + data.ballsInCurrentOver);
        const runsRemaining = data.targetRuns - data.totalRuns;

        if (runsRemaining <= 0) {
            this.setWinProb(100, 0, data.battingTeamShort, data.bowlingTeamShort);
            return;
        }
        if (ballsRemaining <= 0 || data.wickets >= 10) {
            this.setWinProb(0, 100, data.battingTeamShort, data.bowlingTeamShort);
            return;
        }

        // Realistic chase probability formula based on RRR and wickets left
        const wicketsInHand = 10 - data.wickets;
        const requiredRate = (runsRemaining / (ballsRemaining / 6.0));
        let batProb = 50 + (wicketsInHand * 4.5) - (requiredRate * 4.2);
        batProb = Math.max(5, Math.min(95, Math.round(batProb)));
        const bowlProb = 100 - batProb;

        this.setWinProb(batProb, bowlProb, data.battingTeamShort || 'BAT', data.bowlingTeamShort || 'BOWL');
    },

    setWinProb(p1, p2, team1, team2) {
        const bar1 = document.getElementById('win-prob-batting');
        const bar2 = document.getElementById('win-prob-bowling');
        const text1 = document.getElementById('win-prob-text1');
        const text2 = document.getElementById('win-prob-text2');

        if (bar1) bar1.style.width = `${p1}%`;
        if (bar2) bar2.style.width = `${p2}%`;
        if (text1) text1.textContent = `${team1} ${p1}%`;
        if (text2) text2.textContent = `${team2} ${p2}%`;
    },

    updatePitchRadar(data) {
        // Visual pitch indicator
        const ballMarker = document.getElementById('pitch-ball-marker');
        const lengthLabel = document.getElementById('pitch-length-label');
        if (!ballMarker || !lengthLabel) return;

        // Determine ball length based on recent event
        const lengths = [
            { name: 'Yorker Length (Stumps)', top: '22%' },
            { name: 'Full Length (Driveable)', top: '35%' },
            { name: 'Good Length (Corridor of Uncertainty)', top: '50%' },
            { name: 'Back of Length (Rise)', top: '65%' },
            { name: 'Short Ball (Bouncer)', top: '78%' }
        ];

        const randomIdx = (data.totalRuns + data.ballsInCurrentOver) % lengths.length;
        const chosen = lengths[randomIdx];

        ballMarker.style.top = chosen.top;
        lengthLabel.textContent = chosen.name;
    },

    showEventToast(title, message, bgClass = 'bg-blue-600') {
        const toast = document.getElementById('event-toast');
        const tTitle = document.getElementById('event-toast-title');
        const tMsg = document.getElementById('event-toast-msg');

        if (!toast || !tTitle || !tMsg) return;

        tTitle.textContent = title;
        tMsg.textContent = message;
        toast.className = `event-toast show fixed top-20 left-1/2 -translate-x-1/2 z-50 px-6 py-3.5 rounded-2xl text-white shadow-2xl border border-white/20 backdrop-blur-lg ${bgClass}`;

        if (this.toastTimeout) clearTimeout(this.toastTimeout);
        this.toastTimeout = setTimeout(() => {
            toast.className = 'event-toast fixed top-20 left-1/2 -translate-x-1/2 z-50';
        }, 3000);
    },

    updateSimulationDock(isActive, speed) {
        this.isSimulationRunning = isActive;
        this.currentSpeed = speed || 1;

        const statusEl = document.getElementById('sim-status-label');
        if (statusEl) {
            statusEl.textContent = isActive ? `Live Simulation Engine: Running (${speed}x)` : 'Simulation: Paused';
            statusEl.className = isActive ? 'text-emerald-400 font-bold text-xs' : 'text-amber-400 font-bold text-xs';
        }

        document.querySelectorAll('.speed-btn').forEach(btn => {
            const s = parseInt(btn.dataset.speed, 10);
            if (s === this.currentSpeed) {
                btn.className = 'speed-btn px-3 py-1 text-xs font-black rounded-xl bg-blue-600 text-white shadow-md shadow-blue-600/40';
            } else {
                btn.className = 'speed-btn px-3 py-1 text-xs font-semibold rounded-xl bg-gray-800 hover:bg-gray-700 text-gray-300';
            }
        });
    },

    switchTab(tab) {
        this.activeTab = tab;
        document.querySelectorAll('.tab-btn').forEach(btn => {
            if (btn.dataset.tab === tab) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });

        document.querySelectorAll('.tab-pane').forEach(p => p.classList.add('hidden'));
        const activePane = document.getElementById(`tab-${tab}`);
        if (activePane) activePane.classList.remove('hidden');

        if (tab === 'commentary') this.loadCommentary();
        else if (tab === 'scorecard') this.loadScorecard();
        else if (tab === 'analytics') this.loadAnalytics();
    },

    async loadCommentary() {
        if (!this.activeMatchId) return;
        try {
            const page = await window.API.getCommentary(this.activeMatchId, 0, 30);
            const container = document.getElementById('commentary-feed');
            if (!container) return;

            if (!page.content || page.content.length === 0) {
                container.innerHTML = `<div class="p-12 text-center text-gray-400 font-medium">No commentary recorded yet. Deliveries will stream live.</div>`;
                return;
            }

            container.innerHTML = page.content.map(c => this.renderCommentaryRow(c)).join('');
        } catch (e) {
            console.error('Failed to load commentary', e);
        }
    },

    prependCommentaryBall(update) {
        const container = document.getElementById('commentary-feed');
        if (!container) return;

        let badge = update.lastBallDisplay || '1';
        let badgeClass = 'bg-gray-800 text-gray-200 border border-gray-700';
        if (update.four) { badge = '⚡ FOUR'; badgeClass = 'bg-emerald-600 text-white font-black shadow-lg shadow-emerald-600/40'; }
        else if (update.six) { badge = '🚀 SIX'; badgeClass = 'bg-purple-600 text-white font-black shadow-lg shadow-purple-600/40'; }
        else if (update.wicket) { badge = '💥 WICKET'; badgeClass = 'bg-rose-600 text-white font-black shadow-lg shadow-rose-600/40 animate-pulse'; }
        else if (update.extra) { badge = update.extraType; badgeClass = 'bg-amber-600 text-white font-bold'; }

        const rowHtml = `
            <div class="flex items-start gap-4 p-4 border-b border-gray-800/80 bg-blue-950/25 transition">
                <div class="digital-font text-sm font-extrabold text-blue-400 shrink-0 w-12 pt-0.5">${update.oversDisplay}</div>
                <div class="px-3 py-1 rounded-xl text-xs font-black shrink-0 ${badgeClass}">${badge}</div>
                <div class="flex-1">
                    <div class="text-sm font-medium text-gray-100 leading-relaxed">${update.lastBallCommentary}</div>
                    <div class="text-[11px] text-gray-400 mt-1.5 mono-font font-semibold">Total: ${update.totalRuns}/${update.wickets} • RR: ${update.currentRunRate.toFixed(2)}</div>
                </div>
            </div>
        `;

        container.insertAdjacentHTML('afterbegin', rowHtml);
    },

    renderCommentaryRow(c) {
        let badge = c.runsOffBat === 0 && c.extraRuns === 0 ? '•' : (c.runsOffBat + c.extraRuns);
        let badgeClass = 'bg-gray-800 text-gray-300 border border-gray-700';
        if (c.wicket) { badge = '💥 WICKET'; badgeClass = 'bg-rose-600 text-white font-black'; }
        else if (c.runsOffBat === 4) { badge = '⚡ FOUR'; badgeClass = 'bg-emerald-600 text-white font-black'; }
        else if (c.runsOffBat === 6) { badge = '🚀 SIX'; badgeClass = 'bg-purple-600 text-white font-black'; }
        else if (c.extraType && c.extraType !== 'NONE') { badge = c.extraType; badgeClass = 'bg-amber-600 text-white font-bold'; }

        return `
            <div class="flex items-start gap-4 p-4 border-b border-gray-800/60 hover:bg-gray-800/30 transition">
                <div class="digital-font text-sm font-extrabold text-gray-400 shrink-0 w-12 pt-0.5">${c.overString}</div>
                <div class="px-3 py-1 rounded-xl text-xs font-black shrink-0 ${badgeClass}">${badge}</div>
                <div class="flex-1">
                    <div class="text-sm font-medium text-gray-200 leading-relaxed">${c.commentary}</div>
                    <div class="text-[11px] text-gray-400 mt-1.5 mono-font">Score: ${c.totalRuns}/${c.totalWickets}</div>
                </div>
            </div>
        `;
    },

    async loadScorecard() {
        if (!this.activeMatchId) return;
        try {
            const card = await window.API.getScorecard(this.activeMatchId);
            const container = document.getElementById('scorecard-container');
            if (!container) return;

            if (!card.innings || card.innings.length === 0) {
                container.innerHTML = `<div class="p-12 text-center text-gray-400 font-medium">Scorecard pending match play.</div>`;
                return;
            }

            container.innerHTML = card.innings.map(inn => `
                <div class="glass-card rounded-3xl p-6 md:p-8 border border-gray-800/80 mb-6">
                    <div class="flex items-center justify-between pb-4 mb-4 border-b border-gray-800">
                        <div>
                            <div class="text-xs uppercase font-extrabold text-blue-400 tracking-wider">Innings ${inn.inningNumber}</div>
                            <h3 class="text-xl font-black text-white">${inn.battingTeamName}</h3>
                            <div class="text-xs text-gray-400 mt-0.5">Bowled by ${inn.bowlingTeamName}</div>
                        </div>
                        <div class="text-right">
                            <span class="text-3xl font-black digital-font text-white">${inn.totalRuns}/${inn.wickets}</span>
                            <div class="text-xs font-bold text-gray-400 mt-0.5 mono-font">(${inn.oversFormatted} ov • RR ${inn.runRate.toFixed(2)})</div>
                        </div>
                    </div>

                    <!-- Batting Table -->
                    <div class="overflow-x-auto mb-6">
                        <table class="w-full text-left text-xs">
                            <thead class="bg-gray-900/80 text-gray-400 uppercase font-bold text-[11px] tracking-wider">
                                <tr>
                                    <th class="py-3 px-4 rounded-l-xl">Batter</th>
                                    <th class="py-3 px-4">Dismissal</th>
                                    <th class="py-3 px-4 text-right">R</th>
                                    <th class="py-3 px-4 text-right">B</th>
                                    <th class="py-3 px-4 text-right">4s</th>
                                    <th class="py-3 px-4 text-right">6s</th>
                                    <th class="py-3 px-4 text-right rounded-r-xl">SR</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-800/60">
                                ${inn.batting.map(b => `
                                    <tr class="${b.isBatting ? 'bg-blue-600/10' : 'hover:bg-gray-800/30'} transition">
                                        <td class="py-3.5 px-4 font-bold text-white flex items-center gap-2">
                                            <span>${b.name}</span>
                                            ${b.isOnStrike ? '<span class="px-1.5 py-0.5 rounded-full text-[9px] font-black bg-amber-500/20 text-amber-400 border border-amber-500/30">★ STRIKE</span>' : ''}
                                        </td>
                                        <td class="py-3.5 px-4 text-gray-400 font-medium">${b.dismissalDescription}</td>
                                        <td class="py-3.5 px-4 text-right font-black digital-font text-base text-white">${b.runs}</td>
                                        <td class="py-3.5 px-4 text-right mono-font text-gray-300 font-semibold">${b.balls}</td>
                                        <td class="py-3.5 px-4 text-right mono-font text-gray-300 font-semibold">${b.fours}</td>
                                        <td class="py-3.5 px-4 text-right mono-font text-purple-400 font-bold">${b.sixes}</td>
                                        <td class="py-3.5 px-4 text-right mono-font text-amber-400 font-bold">${b.strikeRate.toFixed(1)}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>

                    <div class="text-xs text-gray-400 mb-6 py-2.5 px-4 bg-gray-900/60 rounded-xl flex justify-between border border-gray-800/50">
                        <span>Extras: <strong class="text-white">${inn.totalExtras}</strong> (wd ${inn.wides}, nb ${inn.noBalls}, b ${inn.byes}, lb ${inn.legByes})</span>
                        ${inn.didNotBat && inn.didNotBat.length > 0 ? `<span>Did not bat: <strong class="text-gray-300">${inn.didNotBat.join(', ')}</strong></span>` : ''}
                    </div>

                    <!-- Bowling Table -->
                    <div class="overflow-x-auto">
                        <table class="w-full text-left text-xs">
                            <thead class="bg-gray-900/80 text-gray-400 uppercase font-bold text-[11px] tracking-wider">
                                <tr>
                                    <th class="py-3 px-4 rounded-l-xl">Bowler</th>
                                    <th class="py-3 px-4 text-right">O</th>
                                    <th class="py-3 px-4 text-right">M</th>
                                    <th class="py-3 px-4 text-right">R</th>
                                    <th class="py-3 px-4 text-right">W</th>
                                    <th class="py-3 px-4 text-right rounded-r-xl">ECON</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-800/60">
                                ${inn.bowling.map(bowl => `
                                    <tr class="${bowl.isCurrentBowler ? 'bg-amber-600/10' : 'hover:bg-gray-800/30'} transition">
                                        <td class="py-3.5 px-4 font-bold text-white flex items-center gap-2">
                                            <span>${bowl.name}</span>
                                            ${bowl.isCurrentBowler ? '<span class="px-1.5 py-0.5 rounded-full text-[9px] font-black bg-blue-500/20 text-blue-400 border border-blue-500/30">BOWLING</span>' : ''}
                                        </td>
                                        <td class="py-3.5 px-4 text-right mono-font text-gray-300 font-semibold">${bowl.overs}</td>
                                        <td class="py-3.5 px-4 text-right mono-font text-gray-300 font-semibold">${bowl.maidens}</td>
                                        <td class="py-3.5 px-4 text-right mono-font text-gray-300 font-semibold">${bowl.runs}</td>
                                        <td class="py-3.5 px-4 text-right font-black digital-font text-base text-emerald-400">${bowl.wickets}</td>
                                        <td class="py-3.5 px-4 text-right mono-font text-gray-300 font-bold">${bowl.economy.toFixed(2)}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            `).join('');
        } catch (e) {
            console.error('Failed to load scorecard', e);
        }
    },

    async loadAnalytics() {
        if (!this.activeMatchId) return;
        try {
            const analytics = await window.API.getAnalytics(this.activeMatchId);
            const match = this.matches.find(m => m.id === this.activeMatchId) || {};

            window.CricketCharts.renderWormChart(
                'worm-chart-canvas',
                match.team1Name || 'Team 1',
                match.team2Name || 'Team 2',
                analytics.team1Worm || [],
                analytics.team2Worm || []
            );

            window.CricketCharts.renderManhattanChart(
                'manhattan-chart-canvas',
                match.team1Name || 'Team 1',
                match.team2Name || 'Team 2',
                analytics.team1OverRuns || [],
                analytics.team2OverRuns || []
            );
        } catch (e) {
            console.error('Failed to load analytics', e);
        }
    },

    async triggerSimulation(action) {
        if (!this.activeMatchId) return;
        try {
            await window.API.controlSimulation(this.activeMatchId, action, this.currentSpeed);
            if (action === 'RESET') {
                await this.selectMatch(this.activeMatchId);
            }
        } catch (e) {
            console.error(`Simulation action ${action} failed`, e);
        }
    },

    async setSimulationSpeed(speed) {
        if (!this.activeMatchId) return;
        try {
            this.currentSpeed = speed;
            await window.API.controlSimulation(this.activeMatchId, 'SET_SPEED', speed);
            this.updateSimulationDock(this.isSimulationRunning, speed);
        } catch (e) {
            console.error(`Setting speed failed`, e);
        }
    },

    async recordManualBall(runs, extraType, isWicket, dismissalType) {
        if (!this.activeMatchId) return;
        try {
            await window.API.postBall(this.activeMatchId, {
                runsOffBat: runs,
                extraType: extraType,
                extraRuns: 0,
                isWicket: isWicket,
                dismissalType: dismissalType,
                commentary: ''
            });
        } catch (e) {
            console.error('Failed to record ball', e);
        }
    },

    async handleCreateMatch() {
        const form = document.getElementById('create-match-form');
        if (!form) return;

        const data = {
            title: form.title.value || 'Custom T20 Match',
            venue: form.venue.value || 'Eden Gardens, Kolkata',
            format: form.format.value || 'T20',
            maxOvers: parseInt(form.overs.value || '20', 10),
            team1Name: form.team1Name.value || 'Team Alpha',
            team1Short: form.team1Short.value || 'ALP',
            team1Color: '#2563eb',
            team2Name: form.team2Name.value || 'Team Beta',
            team2Short: form.team2Short.value || 'BET',
            team2Color: '#ea580c',
            tossWinnerTeam: form.tossWinner.value || 'team1',
            tossDecision: form.tossDecision.value || 'bat'
        };

        try {
            const match = await window.API.createMatch(data);
            document.getElementById('create-match-modal')?.classList.add('hidden');
            form.reset();
            await this.loadMatches();
            this.selectMatch(match.id);
        } catch (e) {
            console.error('Failed to create match', e);
        }
    }
};

function setText(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value != null ? value : '';
}

window.App = App;
window.addEventListener('DOMContentLoaded', () => App.init());
