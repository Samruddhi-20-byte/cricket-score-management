package com.cricket.score.dto;

import com.cricket.score.model.MatchFormat;
import com.cricket.score.model.MatchStatus;

public class MatchSummaryDto {
    private Long id;
    private String title;
    private String venue;
    private MatchFormat format;
    private MatchStatus status;
    private int maxOvers;

    private String team1Name;
    private String team1Short;
    private String team1Color;
    private String team1Score; // e.g. "185/4 (20.0)"

    private String team2Name;
    private String team2Short;
    private String team2Color;
    private String team2Score; // e.g. "142/3 (15.2)"

    private String currentBattingTeam;
    private String resultMessage;
    private boolean isSimulationActive;
    private int simulationSpeed;

    public MatchSummaryDto() {}

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getVenue() { return venue; }
    public void setVenue(String venue) { this.venue = venue; }

    public MatchFormat getFormat() { return format; }
    public void setFormat(MatchFormat format) { this.format = format; }

    public MatchStatus getStatus() { return status; }
    public void setStatus(MatchStatus status) { this.status = status; }

    public int getMaxOvers() { return maxOvers; }
    public void setMaxOvers(int maxOvers) { this.maxOvers = maxOvers; }

    public String getTeam1Name() { return team1Name; }
    public void setTeam1Name(String team1Name) { this.team1Name = team1Name; }

    public String getTeam1Short() { return team1Short; }
    public void setTeam1Short(String team1Short) { this.team1Short = team1Short; }

    public String getTeam1Color() { return team1Color; }
    public void setTeam1Color(String team1Color) { this.team1Color = team1Color; }

    public String getTeam1Score() { return team1Score; }
    public void setTeam1Score(String team1Score) { this.team1Score = team1Score; }

    public String getTeam2Name() { return team2Name; }
    public void setTeam2Name(String team2Name) { this.team2Name = team2Name; }

    public String getTeam2Short() { return team2Short; }
    public void setTeam2Short(String team2Short) { this.team2Short = team2Short; }

    public String getTeam2Color() { return team2Color; }
    public void setTeam2Color(String team2Color) { this.team2Color = team2Color; }

    public String getTeam2Score() { return team2Score; }
    public void setTeam2Score(String team2Score) { this.team2Score = team2Score; }

    public String getCurrentBattingTeam() { return currentBattingTeam; }
    public void setCurrentBattingTeam(String currentBattingTeam) { this.currentBattingTeam = currentBattingTeam; }

    public String getResultMessage() { return resultMessage; }
    public void setResultMessage(String resultMessage) { this.resultMessage = resultMessage; }

    public boolean isSimulationActive() { return isSimulationActive; }
    public void setSimulationActive(boolean simulationActive) { isSimulationActive = simulationActive; }

    public int getSimulationSpeed() { return simulationSpeed; }
    public void setSimulationSpeed(int simulationSpeed) { this.simulationSpeed = simulationSpeed; }
}
