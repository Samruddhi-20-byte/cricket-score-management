package com.cricket.score.dto;

import com.cricket.score.model.DismissalType;
import com.cricket.score.model.MatchFormat;
import com.cricket.score.model.MatchStatus;
import java.util.ArrayList;
import java.util.List;

public class ScorecardDto {
    private Long matchId;
    private String title;
    private String venue;
    private MatchFormat format;
    private MatchStatus status;
    private String tossInfo;
    private String resultMessage;
    private List<InningScorecardDto> innings = new ArrayList<>();

    public static class InningScorecardDto {
        private int inningNumber;
        private String battingTeamName;
        private String bowlingTeamName;
        private int totalRuns;
        private int wickets;
        private String oversFormatted;
        private double runRate;

        private int wides;
        private int noBalls;
        private int byes;
        private int legByes;
        private int totalExtras;

        private List<BatsmanScorecardDto> batting = new ArrayList<>();
        private List<BowlerScorecardDto> bowling = new ArrayList<>();
        private List<FallOfWicketDto> fallOfWickets = new ArrayList<>();
        private List<String> didNotBat = new ArrayList<>();

        public InningScorecardDto() {}

        public int getInningNumber() { return inningNumber; }
        public void setInningNumber(int inningNumber) { this.inningNumber = inningNumber; }

        public String getBattingTeamName() { return battingTeamName; }
        public void setBattingTeamName(String battingTeamName) { this.battingTeamName = battingTeamName; }

        public String getBowlingTeamName() { return bowlingTeamName; }
        public void setBowlingTeamName(String bowlingTeamName) { this.bowlingTeamName = bowlingTeamName; }

        public int getTotalRuns() { return totalRuns; }
        public void setTotalRuns(int totalRuns) { this.totalRuns = totalRuns; }

        public int getWickets() { return wickets; }
        public void setWickets(int wickets) { this.wickets = wickets; }

        public String getOversFormatted() { return oversFormatted; }
        public void setOversFormatted(String oversFormatted) { this.oversFormatted = oversFormatted; }

        public double getRunRate() { return runRate; }
        public void setRunRate(double runRate) { this.runRate = runRate; }

        public int getWides() { return wides; }
        public void setWides(int wides) { this.wides = wides; }

        public int getNoBalls() { return noBalls; }
        public void setNoBalls(int noBalls) { this.noBalls = noBalls; }

        public int getByes() { return byes; }
        public void setByes(int byes) { this.byes = byes; }

        public int getLegByes() { return legByes; }
        public void setLegByes(int legByes) { this.legByes = legByes; }

        public int getTotalExtras() { return totalExtras; }
        public void setTotalExtras(int totalExtras) { this.totalExtras = totalExtras; }

        public List<BatsmanScorecardDto> getBatting() { return batting; }
        public void setBatting(List<BatsmanScorecardDto> batting) { this.batting = batting; }

        public List<BowlerScorecardDto> getBowling() { return bowling; }
        public void setBowling(List<BowlerScorecardDto> bowling) { this.bowling = bowling; }

        public List<FallOfWicketDto> getFallOfWickets() { return fallOfWickets; }
        public void setFallOfWickets(List<FallOfWicketDto> fallOfWickets) { this.fallOfWickets = fallOfWickets; }

        public List<String> getDidNotBat() { return didNotBat; }
        public void setDidNotBat(List<String> didNotBat) { this.didNotBat = didNotBat; }
    }

    public static class BatsmanScorecardDto {
        private Long playerId;
        private String name;
        private int runs;
        private int balls;
        private int fours;
        private int sixes;
        private double strikeRate;
        private boolean isOut;
        private DismissalType dismissalType;
        private String bowlerName;
        private String fielderName;
        private String dismissalDescription;
        private boolean isBatting;
        private boolean isOnStrike;

        public BatsmanScorecardDto() {}

        public Long getPlayerId() { return playerId; }
        public void setPlayerId(Long playerId) { this.playerId = playerId; }

        public String getName() { return name; }
        public void setName(String name) { this.name = name; }

        public int getRuns() { return runs; }
        public void setRuns(int runs) { this.runs = runs; }

        public int getBalls() { return balls; }
        public void setBalls(int balls) { this.balls = balls; }

        public int getFours() { return fours; }
        public void setFours(int fours) { this.fours = fours; }

        public int getSixes() { return sixes; }
        public void setSixes(int sixes) { this.sixes = sixes; }

        public double getStrikeRate() { return strikeRate; }
        public void setStrikeRate(double strikeRate) { this.strikeRate = strikeRate; }

        public boolean isOut() { return isOut; }
        public void setOut(boolean out) { isOut = out; }

        public DismissalType getDismissalType() { return dismissalType; }
        public void setDismissalType(DismissalType dismissalType) { this.dismissalType = dismissalType; }

        public String getBowlerName() { return bowlerName; }
        public void setBowlerName(String bowlerName) { this.bowlerName = bowlerName; }

        public String getFielderName() { return fielderName; }
        public void setFielderName(String fielderName) { this.fielderName = fielderName; }

        public String getDismissalDescription() { return dismissalDescription; }
        public void setDismissalDescription(String dismissalDescription) { this.dismissalDescription = dismissalDescription; }

        public boolean isBatting() { return isBatting; }
        public void setBatting(boolean batting) { isBatting = batting; }

        public boolean isOnStrike() { return isOnStrike; }
        public void setOnStrike(boolean onStrike) { isOnStrike = onStrike; }
    }

    public static class BowlerScorecardDto {
        private Long playerId;
        private String name;
        private String overs;
        private int maidens;
        private int runs;
        private int wickets;
        private double economy;
        private boolean isCurrentBowler;

        public BowlerScorecardDto() {}

        public Long getPlayerId() { return playerId; }
        public void setPlayerId(Long playerId) { this.playerId = playerId; }

        public String getName() { return name; }
        public void setName(String name) { this.name = name; }

        public String getOvers() { return overs; }
        public void setOvers(String overs) { this.overs = overs; }

        public int getMaidens() { return maidens; }
        public void setMaidens(int maidens) { this.maidens = maidens; }

        public int getRuns() { return runs; }
        public void setRuns(int runs) { this.runs = runs; }

        public int getWickets() { return wickets; }
        public void setWickets(int wickets) { this.wickets = wickets; }

        public double getEconomy() { return economy; }
        public void setEconomy(double economy) { this.economy = economy; }

        public boolean isCurrentBowler() { return isCurrentBowler; }
        public void setCurrentBowler(boolean currentBowler) { isCurrentBowler = currentBowler; }
    }

    public static class FallOfWicketDto {
        private int wicketNumber;
        private int score;
        private String over;
        private String playerName;

        public FallOfWicketDto() {}

        public FallOfWicketDto(int wicketNumber, int score, String over, String playerName) {
            this.wicketNumber = wicketNumber;
            this.score = score;
            this.over = over;
            this.playerName = playerName;
        }

        public int getWicketNumber() { return wicketNumber; }
        public void setWicketNumber(int wicketNumber) { this.wicketNumber = wicketNumber; }

        public int getScore() { return score; }
        public void setScore(int score) { this.score = score; }

        public String getOver() { return over; }
        public void setOver(String over) { this.over = over; }

        public String getPlayerName() { return playerName; }
        public void setPlayerName(String playerName) { this.playerName = playerName; }
    }

    public ScorecardDto() {}

    public Long getMatchId() { return matchId; }
    public void setMatchId(Long matchId) { this.matchId = matchId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getVenue() { return venue; }
    public void setVenue(String venue) { this.venue = venue; }

    public MatchFormat getFormat() { return format; }
    public void setFormat(MatchFormat format) { this.format = format; }

    public MatchStatus getStatus() { return status; }
    public void setStatus(MatchStatus status) { this.status = status; }

    public String getTossInfo() { return tossInfo; }
    public void setTossInfo(String tossInfo) { this.tossInfo = tossInfo; }

    public String getResultMessage() { return resultMessage; }
    public void setResultMessage(String resultMessage) { this.resultMessage = resultMessage; }

    public List<InningScorecardDto> getInnings() { return innings; }
    public void setInnings(List<InningScorecardDto> innings) { this.innings = innings; }
}
