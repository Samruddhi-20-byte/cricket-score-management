package com.cricket.score.service;

import com.cricket.score.dto.BallEventRequest;
import com.cricket.score.model.*;
import com.cricket.score.repository.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Transactional
class ScoreCalculationServiceTest {

    @Autowired
    private ScoreCalculationService scoreCalculationService;

    @Autowired
    private MatchRepository matchRepository;

    @Autowired
    private TeamRepository teamRepository;

    @Autowired
    private PlayerRepository playerRepository;

    @Autowired
    private InningRepository inningRepository;

    @Autowired
    private BattingRecordRepository battingRecordRepository;

    @Autowired
    private BowlingRecordRepository bowlingRecordRepository;

    private Match testMatch;
    private Inning testInning;
    private Player batsman1;
    private Player batsman2;
    private Player batsman3;
    private Player bowler1;
    private Player bowler2;

    @BeforeEach
    void setUp() {
        // Create custom teams and players for clean unit test assertion
        Team batTeam = teamRepository.save(new Team("Unit Test Batsmen", "UTB", "#000", "#fff"));
        Team bowlTeam = teamRepository.save(new Team("Unit Test Bowlers", "UTL", "#111", "#fff"));

        batsman1 = playerRepository.save(new Player("Alpha Batter", PlayerRole.BATSMAN, "UT"));
        batsman2 = playerRepository.save(new Player("Beta Batter", PlayerRole.BATSMAN, "UT"));
        batsman3 = playerRepository.save(new Player("Gamma Batter", PlayerRole.BATSMAN, "UT"));
        batTeam.setPlayers(new java.util.ArrayList<>(List.of(batsman1, batsman2, batsman3)));
        teamRepository.save(batTeam);

        bowler1 = playerRepository.save(new Player("Speedy Bowler", PlayerRole.BOWLER, "UT"));
        bowler2 = playerRepository.save(new Player("Spin Bowler", PlayerRole.BOWLER, "UT"));
        bowlTeam.setPlayers(new java.util.ArrayList<>(List.of(bowler1, bowler2)));
        teamRepository.save(bowlTeam);

        testMatch = new Match("Test Match", "Test Arena", MatchFormat.T20, 20, batTeam, bowlTeam);
        testMatch.setStatus(MatchStatus.LIVE);
        testMatch = matchRepository.save(testMatch);

        testInning = new Inning(testMatch, 1, batTeam, bowlTeam);
        testInning.setStatus(InningStatus.IN_PROGRESS);
        testInning = inningRepository.save(testInning);

        testMatch.getInnings().add(testInning);
        testMatch.setCurrentInningIndex(0);
        matchRepository.save(testMatch);

        scoreCalculationService.ensurePlayersInitialized(testMatch, testInning);
    }

    @Test
    @DisplayName("Single run should increment total runs, batsman runs, and rotate strike")
    void testSingleRunAndStrikeRotation() {
        Long initialStrikerId = testInning.getCurrentStrikerId();
        Long initialNonStrikerId = testInning.getCurrentNonStrikerId();

        BallEventRequest ball = new BallEventRequest(1, ExtraType.NONE, 0, false, DismissalType.NOT_OUT, "Single run");
        scoreCalculationService.processBall(testMatch, ball);

        assertEquals(1, testInning.getTotalRuns());
        assertEquals(0, testInning.getCompletedOvers());
        assertEquals(1, testInning.getBallsInCurrentOver());

        BattingRecord b1Rec = battingRecordRepository.findByInningIdAndPlayerId(testInning.getId(), initialStrikerId).orElseThrow();
        assertEquals(1, b1Rec.getRunsScored());
        assertEquals(1, b1Rec.getBallsFaced());

        // Strike rotated: striker should now be initial non-striker
        assertEquals(initialNonStrikerId, testInning.getCurrentStrikerId());
        assertEquals(initialStrikerId, testInning.getCurrentNonStrikerId());
    }

    @Test
    @DisplayName("Boundary Four should increment runs, four count, and keep striker on strike")
    void testBoundaryFour() {
        Long strikerId = testInning.getCurrentStrikerId();

        BallEventRequest ball = new BallEventRequest(4, ExtraType.NONE, 0, false, DismissalType.NOT_OUT, "Four!");
        scoreCalculationService.processBall(testMatch, ball);

        assertEquals(4, testInning.getTotalRuns());
        assertEquals(1, testInning.getBallsInCurrentOver());

        BattingRecord rec = battingRecordRepository.findByInningIdAndPlayerId(testInning.getId(), strikerId).orElseThrow();
        assertEquals(4, rec.getRunsScored());
        assertEquals(1, rec.getBallsFaced());
        assertEquals(1, rec.getFours());
        assertEquals(0, rec.getSixes());

        // Even runs: striker remains on strike
        assertEquals(strikerId, testInning.getCurrentStrikerId());
    }

    @Test
    @DisplayName("Wide delivery should add 1 extra run without consuming a legal ball")
    void testWideDelivery() {
        Long strikerId = testInning.getCurrentStrikerId();

        BallEventRequest ball = new BallEventRequest(0, ExtraType.WIDE, 0, false, DismissalType.NOT_OUT, "Wide ball");
        scoreCalculationService.processBall(testMatch, ball);

        assertEquals(1, testInning.getTotalRuns());
        assertEquals(1, testInning.getWides());
        assertEquals(0, testInning.getBallsInCurrentOver()); // Not counted as legal delivery

        BattingRecord rec = battingRecordRepository.findByInningIdAndPlayerId(testInning.getId(), strikerId).orElseThrow();
        assertEquals(0, rec.getBallsFaced()); // Wide doesn't count against balls faced
        assertEquals(0, rec.getRunsScored());
    }

    @Test
    @DisplayName("Over completion: 6 legal deliveries complete over and swap strike")
    void testOverCompletion() {
        Long initialStriker = testInning.getCurrentStrikerId();
        Long initialNonStriker = testInning.getCurrentNonStrikerId();

        // Bowl 6 dot balls
        for (int i = 0; i < 6; i++) {
            scoreCalculationService.processBall(testMatch, new BallEventRequest(0, ExtraType.NONE, 0, false, DismissalType.NOT_OUT, "Dot"));
        }

        assertEquals(1, testInning.getCompletedOvers());
        assertEquals(0, testInning.getBallsInCurrentOver());

        // At end of over, strike rotates so initial non-striker faces the next over
        assertEquals(initialNonStriker, testInning.getCurrentStrikerId());
        assertEquals(initialStriker, testInning.getCurrentNonStrikerId());
    }

    @Test
    @DisplayName("Wicket should mark batsman out, increment team wickets, and bring next batsman")
    void testWicketHandling() {
        Long strikerId = testInning.getCurrentStrikerId();

        BallEventRequest wicketBall = new BallEventRequest(0, ExtraType.NONE, 0, true, DismissalType.BOWLED, "Bowled him!");
        scoreCalculationService.processBall(testMatch, wicketBall);

        assertEquals(1, testInning.getWickets());

        BattingRecord outRec = battingRecordRepository.findByInningIdAndPlayerId(testInning.getId(), strikerId).orElseThrow();
        assertTrue(outRec.isOut());
        assertEquals(DismissalType.BOWLED, outRec.getDismissalType());

        // Next batsman (batsman3) should now be on strike
        assertEquals(batsman3.getId(), testInning.getCurrentStrikerId());
        BattingRecord newRec = battingRecordRepository.findByInningIdAndPlayerId(testInning.getId(), batsman3.getId()).orElseThrow();
        assertTrue(newRec.isBatting());
        assertTrue(newRec.isOnStrike());
    }

    @Test
    @DisplayName("Second innings run chase target completion should mark match completed with winner")
    void testRunChaseTargetCompletion() {
        // Setup 2nd inning
        testInning.setStatus(InningStatus.COMPLETED);
        testInning.setTotalRuns(10); // Target will be 11

        Inning inn2 = new Inning(testMatch, 2, testMatch.getTeam2(), testMatch.getTeam1());
        inn2.setTargetRuns(11);
        inn2.setStatus(InningStatus.IN_PROGRESS);
        inn2 = inningRepository.save(inn2);
        testMatch.getInnings().add(inn2);
        testMatch.setCurrentInningIndex(1);
        matchRepository.save(testMatch);

        scoreCalculationService.ensurePlayersInitialized(testMatch, inn2);

        // Hit a six (6)
        scoreCalculationService.processBall(testMatch, new BallEventRequest(6, ExtraType.NONE, 0, false, DismissalType.NOT_OUT, "Six"));
        assertEquals(6, inn2.getTotalRuns());
        assertEquals(MatchStatus.LIVE, testMatch.getStatus());

        // Hit another six (6) -> Total 12 >= 11 Target!
        scoreCalculationService.processBall(testMatch, new BallEventRequest(6, ExtraType.NONE, 0, false, DismissalType.NOT_OUT, "Six to win!"));

        assertEquals(12, inn2.getTotalRuns());
        assertEquals(MatchStatus.COMPLETED, testMatch.getStatus());
        assertEquals(testMatch.getTeam2().getId(), testMatch.getWinner().getId());
        assertTrue(testMatch.getResultMessage().contains("won by 10 wickets"));
    }
}
