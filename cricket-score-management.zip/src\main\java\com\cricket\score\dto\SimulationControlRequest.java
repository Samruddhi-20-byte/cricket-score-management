package com.cricket.score.dto;

public class SimulationControlRequest {
    private String action; // START, PAUSE, RESUME, STEP, RESET, SET_SPEED
    private Integer speed; // 1, 2, 5

    public SimulationControlRequest() {}

    public SimulationControlRequest(String action, Integer speed) {
        this.action = action;
        this.speed = speed;
    }

    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }

    public Integer getSpeed() { return speed; }
    public void setSpeed(Integer speed) { this.speed = speed; }
}
