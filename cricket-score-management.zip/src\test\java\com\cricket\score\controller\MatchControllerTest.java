package com.cricket.score.controller;

import com.cricket.score.model.Match;
import com.cricket.score.repository.MatchRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class MatchControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private MatchRepository matchRepository;

    @Test
    @DisplayName("GET /api/matches returns list of seeded matches")
    void testGetAllMatches() throws Exception {
        mockMvc.perform(get("/api/matches"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$", hasSize(greaterThanOrEqualTo(1))))
                .andExpect(jsonPath("$[0].title", notNullValue()));
    }

    @Test
    @DisplayName("GET /api/matches/{id} returns live score DTO with active batsman and bowler")
    void testGetLiveScore() throws Exception {
        Match match = matchRepository.findAll().get(0);

        mockMvc.perform(get("/api/matches/" + match.getId()))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.matchId", is(match.getId().intValue())))
                .andExpect(jsonPath("$.totalRuns", greaterThanOrEqualTo(0)))
                .andExpect(jsonPath("$.battingTeamName", notNullValue()));
    }

    @Test
    @DisplayName("GET /api/matches/{id}/scorecard returns full innings scorecard")
    void testGetScorecard() throws Exception {
        Match match = matchRepository.findAll().get(0);

        mockMvc.perform(get("/api/matches/" + match.getId() + "/scorecard"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.matchId", is(match.getId().intValue())))
                .andExpect(jsonPath("$.innings", hasSize(greaterThanOrEqualTo(1))));
    }

    @Test
    @DisplayName("GET /api/matches/{id}/analytics returns Manhattan and Worm chart datasets")
    void testGetAnalytics() throws Exception {
        Match match = matchRepository.findAll().get(0);

        mockMvc.perform(get("/api/matches/" + match.getId() + "/analytics"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.matchId", is(match.getId().intValue())))
                .andExpect(jsonPath("$.team1Worm", notNullValue()));
    }

    @Test
    @DisplayName("POST /api/matches/{id}/simulation/control allows pause and resume")
    void testSimulationControl() throws Exception {
        Match match = matchRepository.findAll().get(0);

        mockMvc.perform(post("/api/matches/" + match.getId() + "/simulation/control")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"action\": \"PAUSE\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status", is("success")))
                .andExpect(jsonPath("$.action", is("PAUSE")));
    }
}
