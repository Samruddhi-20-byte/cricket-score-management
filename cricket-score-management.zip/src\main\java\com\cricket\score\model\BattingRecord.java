package com.cricket.score.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

@Entity
@Table(name = "batting_records")
public class BattingRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "player_id", nullable = false)
    private Player player;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "inning_id")
    private Inning inning;

    private int runsScored = 0;
    private int ballsFaced = 0;
    private int fours = 0;
    private int sixes = 0;

    private boolean isOut = false;

    @Enumerated(EnumType.STRING)
    private DismissalType dismissalType = DismissalType.NOT_OUT;

    private String bowlerName;
    private String fielderName;

    private int battingPosition = 0;
    private boolean isBatting = false; // currently at crease
    private boolean isOnStrike = false;

    public BattingRecord() {}

    public BattingRecord(Player player, Inning inning, int battingPosition) {
        this.player = player;
        this.inning = inning;
        this.battingPosition = battingPosition;
    }

    public double getStrikeRate() {
        if (ballsFaced == 0) return 0.0;
        return Math.round(((double) runsScored / ballsFaced) * 100.0 * 10.0) / 10.0;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public Inning getInning() {
        return inning;
    }

    public void setInning(Inning inning) {
        this.inning = inning;
    }

    public int getRunsScored() {
        return runsScored;
    }

    public void setRunsScored(int runsScored) {
        this.runsScored = runsScored;
    }

    public int getBallsFaced() {
        return ballsFaced;
    }

    public void setBallsFaced(int ballsFaced) {
        this.ballsFaced = ballsFaced;
    }

    public int getFours() {
        return fours;
    }

    public void setFours(int fours) {
        this.fours = fours;
    }

    public int getSixes() {
        return sixes;
    }

    public void setSixes(int sixes) {
        this.sixes = sixes;
    }

    public boolean isOut() {
        return isOut;
    }

    public void setOut(boolean out) {
        isOut = out;
    }

    public DismissalType getDismissalType() {
        return dismissalType;
    }

    public void setDismissalType(DismissalType dismissalType) {
        this.dismissalType = dismissalType;
    }

    public String getBowlerName() {
        return bowlerName;
    }

    public void setBowlerName(String bowlerName) {
        this.bowlerName = bowlerName;
    }

    public String getFielderName() {
        return fielderName;
    }

    public void setFielderName(String fielderName) {
        this.fielderName = fielderName;
    }

    public int getBattingPosition() {
        return battingPosition;
    }

    public void setBattingPosition(int battingPosition) {
        this.battingPosition = battingPosition;
    }

    public boolean isBatting() {
        return isBatting;
    }

    public void setBatting(boolean batting) {
        isBatting = batting;
    }

    public boolean isOnStrike() {
        return isOnStrike;
    }

    public void setOnStrike(boolean onStrike) {
        isOnStrike = onStrike;
    }
}
