package com.cricket.score.model;

public enum MatchFormat {
    T20(20),
    ODI(50);

    private final int defaultOvers;

    MatchFormat(int defaultOvers) {
        this.defaultOvers = defaultOvers;
    }

    public int getDefaultOvers() {
        return defaultOvers;
    }
}
