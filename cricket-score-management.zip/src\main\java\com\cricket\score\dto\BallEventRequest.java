package com.cricket.score.dto;

import com.cricket.score.model.DismissalType;
import com.cricket.score.model.ExtraType;

public class BallEventRequest {
    private int runsOffBat = 0;
    private ExtraType extraType = ExtraType.NONE;
    private int extraRuns = 0;
    private boolean isWicket = false;
    private DismissalType dismissalType = DismissalType.NOT_OUT;
    private String commentary;

    public BallEventRequest() {}

    public BallEventRequest(int runsOffBat, ExtraType extraType, int extraRuns, boolean isWicket, DismissalType dismissalType, String commentary) {
        this.runsOffBat = runsOffBat;
        this.extraType = extraType;
        this.extraRuns = extraRuns;
        this.isWicket = isWicket;
        this.dismissalType = dismissalType;
        this.commentary = commentary;
    }

    public int getRunsOffBat() { return runsOffBat; }
    public void setRunsOffBat(int runsOffBat) { this.runsOffBat = runsOffBat; }

    public ExtraType getExtraType() { return extraType; }
    public void setExtraType(ExtraType extraType) { this.extraType = extraType; }

    public int getExtraRuns() { return extraRuns; }
    public void setExtraRuns(int extraRuns) { this.extraRuns = extraRuns; }

    public boolean isWicket() { return isWicket; }
    public void setWicket(boolean wicket) { isWicket = wicket; }

    public DismissalType getDismissalType() { return dismissalType; }
    public void setDismissalType(DismissalType dismissalType) { this.dismissalType = dismissalType; }

    public String getCommentary() { return commentary; }
    public void setCommentary(String commentary) { this.commentary = commentary; }
}
