package com.cricket.score.repository;

import com.cricket.score.model.BowlingRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface BowlingRecordRepository extends JpaRepository<BowlingRecord, Long> {
    List<BowlingRecord> findByInningIdOrderByBowlingPositionAsc(Long inningId);
    Optional<BowlingRecord> findByInningIdAndPlayerId(Long inningId, Long playerId);
}
