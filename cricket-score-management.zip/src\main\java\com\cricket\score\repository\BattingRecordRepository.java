package com.cricket.score.repository;

import com.cricket.score.model.BattingRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface BattingRecordRepository extends JpaRepository<BattingRecord, Long> {
    List<BattingRecord> findByInningIdOrderByBattingPositionAsc(Long inningId);
    Optional<BattingRecord> findByInningIdAndPlayerId(Long inningId, Long playerId);
}
