package com.cricket.score.service;

import com.cricket.score.dto.BallEventRequest;
import com.cricket.score.model.*;
import com.cricket.score.repository.BallDeliveryRepository;
import com.cricket.score.repository.BattingRecordRepository;
import com.cricket.score.repository.BowlingRecordRepository;
import com.cricket.score.repository.InningRepository;
import com.cricket.score.repository.MatchRepository;
import jakarta.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledFuture;

@Service
public class MatchSimulationEngine {

    private static final Logger log = LoggerFactory.getLogger(MatchSimulationEngine.class);

    private final MatchRepository matchRepository;
    private final InningRepository inningRepository;
    private final BattingRecordRepository battingRecordRepository;
    private final BowlingRecordRepository bowlingRecordRepository;
    private final BallDeliveryRepository ballDeliveryRepository;
    private final MatchService matchService;
    private final ScoreCalculationService scoreCalculationService;
    private final ThreadPoolTaskScheduler taskScheduler;

    private final Map<Long, ScheduledFuture<?>> activeTasks = new ConcurrentHashMap<>();
    private final Random random = new Random();

    public MatchSimulationEngine(
            MatchRepository matchRepository,
            InningRepository inningRepository,
            BattingRecordRepository battingRecordRepository,
            BowlingRecordRepository bowlingRecordRepository,
            BallDeliveryRepository ballDeliveryRepository,
            @Lazy MatchService matchService,
            ScoreCalculationService scoreCalculationService
    ) {
        this.matchRepository = matchRepository;
        this.inningRepository = inningRepository;
        this.battingRecordRepository = battingRecordRepository;
        this.bowlingRecordRepository = bowlingRecordRepository;
        this.ballDeliveryRepository = ballDeliveryRepository;
        this.matchService = matchService;
        this.scoreCalculationService = scoreCalculationService;

        this.taskScheduler = new ThreadPoolTaskScheduler();
        this.taskScheduler.setPoolSize(4);
        this.taskScheduler.setThreadNamePrefix("cricket-sim-");
        this.taskScheduler.initialize();
    }

    public synchronized void startSimulation(Long matchId, int speed) {
        pauseSimulation(matchId); // Cancel any previous task

        Match match = matchRepository.findById(matchId).orElse(null);
        if (match == null || match.getStatus() == MatchStatus.COMPLETED) {
            log.info("Match {} is completed or not found. Cannot start simulation.", matchId);
            return;
        }

        match.setSimulationActive(true);
        match.setSimulationSpeed(speed > 0 ? speed : 1);
        if (match.getStatus() == MatchStatus.SCHEDULED || match.getStatus() == MatchStatus.PAUSED) {
            match.setStatus(MatchStatus.LIVE);
        }
        matchRepository.save(match);

        long intervalMs = computeInterval(match.getSimulationSpeed());
        ScheduledFuture<?> future = taskScheduler.scheduleWithFixedDelay(() -> executeSimulationStep(matchId), Duration.ofMillis(intervalMs));
        activeTasks.put(matchId, future);
        log.info("Started simulation for match {} at speed {}x (interval {}ms)", matchId, match.getSimulationSpeed(), intervalMs);
    }

    public synchronized void pauseSimulation(Long matchId) {
        ScheduledFuture<?> future = activeTasks.remove(matchId);
        if (future != null) {
            future.cancel(false);
            log.info("Paused simulation for match {}", matchId);
        }
        matchRepository.findById(matchId).ifPresent(m -> {
            m.setSimulationActive(false);
            if (m.getStatus() == MatchStatus.LIVE) {
                m.setStatus(MatchStatus.PAUSED);
            }
            matchRepository.save(m);
        });
    }

    public synchronized void setSpeed(Long matchId, int speed) {
        Match match = matchRepository.findById(matchId).orElse(null);
        if (match == null) return;
        match.setSimulationSpeed(speed);
        matchRepository.save(match);

        if (activeTasks.containsKey(matchId)) {
            startSimulation(matchId, speed);
        }
    }

    public synchronized void stepSimulation(Long matchId) {
        executeSimulationStep(matchId);
    }

    @Transactional
    public synchronized void resetMatch(Long matchId) {
        pauseSimulation(matchId);

        Match match = matchRepository.findById(matchId).orElse(null);
        if (match == null) return;

        for (Inning inn : match.getInnings()) {
            ballDeliveryRepository.deleteAll(ballDeliveryRepository.findByInningIdOrderByIdAsc(inn.getId()));
            battingRecordRepository.deleteAll(battingRecordRepository.findByInningIdOrderByBattingPositionAsc(inn.getId()));
            bowlingRecordRepository.deleteAll(bowlingRecordRepository.findByInningIdOrderByBowlingPositionAsc(inn.getId()));

            inn.setTotalRuns(0);
            inn.setWickets(0);
            inn.setCompletedOvers(0);
            inn.setBallsInCurrentOver(0);
            inn.setWides(0);
            inn.setNoBalls(0);
            inn.setByes(0);
            inn.setLegByes(0);
            inn.setStatus(inn.getInningNumber() == 1 ? InningStatus.IN_PROGRESS : InningStatus.YET_TO_BAT);
            inn.setCurrentStrikerId(null);
            inn.setCurrentNonStrikerId(null);
            inn.setCurrentBowlerId(null);
            if (inn.getInningNumber() == 2) {
                inn.setTargetRuns(null);
            }
            inningRepository.save(inn);
        }

        match.setCurrentInningIndex(0);
        match.setStatus(MatchStatus.LIVE);
        match.setWinner(null);
        match.setResultMessage("Match reset. Live scoring ready.");
        match.setSimulationActive(false);
        matchRepository.save(match);

        Inning firstInning = match.getInnings().get(0);
        scoreCalculationService.ensurePlayersInitialized(match, firstInning);

        matchService.applyBallDelivery(matchId, new BallEventRequest(0, ExtraType.NONE, 0, false, DismissalType.NOT_OUT, "Match restarted! Bowler steams in for the first delivery."));
        log.info("Reset match {}", matchId);
    }

    private void executeSimulationStep(Long matchId) {
        try {
            Match match = matchRepository.findById(matchId).orElse(null);
            if (match == null || match.getStatus() == MatchStatus.COMPLETED) {
                pauseSimulation(matchId);
                return;
            }

            Inning inning = match.getCurrentInning();
            if (inning == null || inning.getStatus() == InningStatus.COMPLETED) {
                pauseSimulation(matchId);
                return;
            }

            BallEventRequest ball = generateRandomBall(match, inning);
            matchService.applyBallDelivery(matchId, ball);

            // If match completed after this ball, stop simulation
            Match updated = matchRepository.findById(matchId).orElse(null);
            if (updated != null && updated.getStatus() == MatchStatus.COMPLETED) {
                pauseSimulation(matchId);
            }
        } catch (Exception e) {
            log.error("Error during simulation step for match {}", matchId, e);
        }
    }

    public BallEventRequest generateRandomBall(Match match, Inning inning) {
        int roll = random.nextInt(100);
        int overNum = inning.getCompletedOvers();
        boolean isDeathOvers = overNum >= (match.getMaxOvers() - 4);
        int wickets = inning.getWickets();

        // Adjust probabilities for death overs or tailenders
        int wicketProb = isDeathOvers ? 6 : (wickets >= 7 ? 6 : 4);
        int sixProb = isDeathOvers ? 9 : 4;
        int fourProb = isDeathOvers ? 16 : 12;
        int wideProb = 3;
        int noBallProb = 1;

        if (roll < wicketProb) {
            DismissalType type = pickRandomDismissal();
            return new BallEventRequest(0, ExtraType.NONE, 0, true, type, null);
        }
        roll -= wicketProb;

        if (roll < wideProb) {
            return new BallEventRequest(0, ExtraType.WIDE, 0, false, DismissalType.NOT_OUT, null);
        }
        roll -= wideProb;

        if (roll < noBallProb) {
            int runs = (random.nextBoolean()) ? 4 : (random.nextInt(3) == 0 ? 6 : 1);
            return new BallEventRequest(runs, ExtraType.NO_BALL, 0, false, DismissalType.NOT_OUT, null);
        }
        roll -= noBallProb;

        if (roll < sixProb) {
            return new BallEventRequest(6, ExtraType.NONE, 0, false, DismissalType.NOT_OUT, null);
        }
        roll -= sixProb;

        if (roll < fourProb) {
            return new BallEventRequest(4, ExtraType.NONE, 0, false, DismissalType.NOT_OUT, null);
        }
        roll -= fourProb;

        // Remaining outcomes: 0, 1, 2, 3 runs
        if (roll < 36) {
            return new BallEventRequest(0, ExtraType.NONE, 0, false, DismissalType.NOT_OUT, null);
        } else if (roll < 75) {
            return new BallEventRequest(1, ExtraType.NONE, 0, false, DismissalType.NOT_OUT, null);
        } else if (roll < 93) {
            return new BallEventRequest(2, ExtraType.NONE, 0, false, DismissalType.NOT_OUT, null);
        } else {
            return new BallEventRequest(3, ExtraType.NONE, 0, false, DismissalType.NOT_OUT, null);
        }
    }

    private DismissalType pickRandomDismissal() {
        int r = random.nextInt(10);
        if (r < 4) return DismissalType.CAUGHT;
        if (r < 7) return DismissalType.BOWLED;
        if (r < 9) return DismissalType.LBW;
        return DismissalType.RUN_OUT;
    }

    private long computeInterval(int speed) {
        return switch (speed) {
            case 5 -> 600L;
            case 2 -> 1500L;
            default -> 3000L;
        };
    }

    @PreDestroy
    public void cleanup() {
        activeTasks.values().forEach(future -> future.cancel(true));
        activeTasks.clear();
        taskScheduler.shutdown();
    }
}
