// CricPulse WebSocket Client with STOMP and Auto-Reconnect
class CricketWebSocketManager {
    constructor() {
        this.stompClient = null;
        this.connected = false;
        this.currentMatchId = null;
        this.matchSubscription = null;
        this.matchesSubscription = null;
        this.onLiveUpdateCallback = null;
        this.onMatchSummaryCallback = null;
        this.onConnectionChangeCallback = null;
        this.reconnectTimer = null;
    }

    connect(onConnected) {
        if (this.stompClient && this.connected) return;

        this.updateStatus('connecting');

        try {
            const socket = new SockJS('/ws-cricket');
            this.stompClient = Stomp.over(socket);
            this.stompClient.debug = () => {}; // quiet console logging

            this.stompClient.connect({}, (frame) => {
                this.connected = true;
                this.updateStatus('connected');
                logStatus('WebSocket connected successfully');

                // Subscribe to matches list updates
                this.matchesSubscription = this.stompClient.subscribe('/topic/matches', (message) => {
                    if (this.onMatchSummaryCallback) {
                        try {
                            const summary = JSON.parse(message.body);
                            this.onMatchSummaryCallback(summary);
                        } catch (e) {
                            console.error('Failed to parse match summary update', e);
                        }
                    }
                });

                // Subscribe to current match if set
                if (this.currentMatchId) {
                    this.subscribeToMatch(this.currentMatchId);
                }

                if (onConnected) onConnected();
            }, (error) => {
                this.connected = false;
                this.updateStatus('disconnected');
                logStatus('WebSocket connection error, scheduling reconnect in 3s');
                this.scheduleReconnect();
            });
        } catch (err) {
            this.connected = false;
            this.updateStatus('disconnected');
            this.scheduleReconnect();
        }
    }

    subscribeToMatch(matchId) {
        this.currentMatchId = matchId;
        if (!this.connected || !this.stompClient) return;

        if (this.matchSubscription) {
            this.matchSubscription.unsubscribe();
            this.matchSubscription = null;
        }

        const destination = `/topic/match/${matchId}`;
        this.matchSubscription = this.stompClient.subscribe(destination, (message) => {
            if (this.onLiveUpdateCallback) {
                try {
                    const update = JSON.parse(message.body);
                    this.onLiveUpdateCallback(update);
                } catch (e) {
                    console.error('Failed to parse live update', e);
                }
            }
        });
        logStatus(`Subscribed to ${destination}`);
    }

    scheduleReconnect() {
        if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
        this.reconnectTimer = setTimeout(() => {
            logStatus('Attempting to reconnect WebSocket...');
            this.connect();
        }, 3000);
    }

    updateStatus(status) {
        if (this.onConnectionChangeCallback) {
            this.onConnectionChangeCallback(status);
        }
    }

    onLiveUpdate(callback) {
        this.onLiveUpdateCallback = callback;
    }

    onMatchSummary(callback) {
        this.onMatchSummaryCallback = callback;
    }

    onConnectionChange(callback) {
        this.onConnectionChangeCallback = callback;
    }
}

function logStatus(msg) {
    // console.log('[CricketWS]', msg);
}

window.CricketWS = new CricketWebSocketManager();
