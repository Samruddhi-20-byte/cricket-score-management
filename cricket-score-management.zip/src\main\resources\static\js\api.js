// CricPulse REST API Client
const API_BASE = '/api/matches';

const API = {
    async getMatches() {
        const res = await fetch(API_BASE);
        if (!res.ok) throw new Error('Failed to fetch matches');
        return res.json();
    },

    async getLiveScore(id) {
        const res = await fetch(`${API_BASE}/${id}`);
        if (!res.ok) throw new Error(`Failed to fetch live score for match ${id}`);
        return res.json();
    },

    async getScorecard(id) {
        const res = await fetch(`${API_BASE}/${id}/scorecard`);
        if (!res.ok) throw new Error(`Failed to fetch scorecard for match ${id}`);
        return res.json();
    },

    async getCommentary(id, page = 0, size = 25) {
        const res = await fetch(`${API_BASE}/${id}/commentary?page=${page}&size=${size}`);
        if (!res.ok) throw new Error(`Failed to fetch commentary for match ${id}`);
        return res.json();
    },

    async getAnalytics(id) {
        const res = await fetch(`${API_BASE}/${id}/analytics`);
        if (!res.ok) throw new Error(`Failed to fetch analytics for match ${id}`);
        return res.json();
    },

    async controlSimulation(id, action, speed = 1) {
        const res = await fetch(`${API_BASE}/${id}/simulation/control`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action, speed })
        });
        if (!res.ok) throw new Error(`Failed to execute simulation control ${action}`);
        return res.json();
    },

    async createMatch(matchData) {
        const res = await fetch(API_BASE, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(matchData)
        });
        if (!res.ok) throw new Error('Failed to create match');
        return res.json();
    },

    async postBall(id, ballData) {
        const res = await fetch(`${API_BASE}/${id}/balls`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(ballData)
        });
        if (!res.ok) throw new Error('Failed to record ball delivery');
        return res.json();
    }
};

window.API = API;
