package com.cricket.score.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

@Entity
@Table(name = "bowling_records")
public class BowlingRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "player_id", nullable = false)
    private Player player;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "inning_id")
    private Inning inning;

    private int completedOvers = 0;
    private int ballsInCurrentOver = 0;
    private int maidenOvers = 0;
    private int runsConceded = 0;
    private int wickets = 0;
    private int bowlingPosition = 0;
    private boolean isCurrentBowler = false;

    public BowlingRecord() {}

    public BowlingRecord(Player player, Inning inning, int bowlingPosition) {
        this.player = player;
        this.inning = inning;
        this.bowlingPosition = bowlingPosition;
    }

    public double getOversFormatted() {
        return completedOvers + (ballsInCurrentOver * 0.1);
    }

    public double getEconomy() {
        int totalBalls = (completedOvers * 6) + ballsInCurrentOver;
        if (totalBalls == 0) return 0.0;
        double overs = totalBalls / 6.0;
        return Math.round((runsConceded / overs) * 100.0) / 100.0;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public Inning getInning() {
        return inning;
    }

    public void setInning(Inning inning) {
        this.inning = inning;
    }

    public int getCompletedOvers() {
        return completedOvers;
    }

    public void setCompletedOvers(int completedOvers) {
        this.completedOvers = completedOvers;
    }

    public int getBallsInCurrentOver() {
        return ballsInCurrentOver;
    }

    public void setBallsInCurrentOver(int ballsInCurrentOver) {
        this.ballsInCurrentOver = ballsInCurrentOver;
    }

    public int getMaidenOvers() {
        return maidenOvers;
    }

    public void setMaidenOvers(int maidenOvers) {
        this.maidenOvers = maidenOvers;
    }

    public int getRunsConceded() {
        return runsConceded;
    }

    public void setRunsConceded(int runsConceded) {
        this.runsConceded = runsConceded;
    }

    public int getWickets() {
        return wickets;
    }

    public void setWickets(int wickets) {
        this.wickets = wickets;
    }

    public int getBowlingPosition() {
        return bowlingPosition;
    }

    public void setBowlingPosition(int bowlingPosition) {
        this.bowlingPosition = bowlingPosition;
    }

    public boolean isCurrentBowler() {
        return isCurrentBowler;
    }

    public void setCurrentBowler(boolean currentBowler) {
        isCurrentBowler = currentBowler;
    }
}
