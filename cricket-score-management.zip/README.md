# 🏏 CricPulse | Scalable Real-Time Cricket Score Management & Simulation Engine

A high-performance, broadcast-grade cricket scoring and live match simulation platform built with **Spring Boot 3 (Java 21)**, **WebSockets (STOMP)**, **Spring Data JPA**, **H2 In-Memory Database**, and a **modern responsive TV broadcast dashboard**.

---

## 🌟 Key Features

- ⚡ **Real-Time Live Scoring Engine**: Low-latency push notifications via WebSockets (STOMP) for score deltas, boundary flurries, wickets, and milestones.
- 🎯 **Authentic Cricket Rules**:
  - Full strike rotation on singles, odd runs, and end of over (6 legal deliveries).
  - Accurate extras handling (Wides, No-Balls, Byes, Leg Byes, Penalties).
  - Fall of wickets, next batsman assignment, and all-out innings transitions.
  - Required Run Rate (RRR), Current Run Rate (CRR), and target chase calculations.
- 🎲 **Multi-Threaded Simulation Engine**:
  - Probability-weighted ball generation simulating realistic cricket match dynamics (death overs spikes, powerplay flurries, tailender pressure).
  - Play, Pause, Resume, Step 1 Ball, Fast-Forward (1x, 2x, 5x), and Reset controls.
- 📊 **Visual Analytics**:
  - **Worm Chart**: Cumulative runs progression curve comparing both teams over-by-over.
  - **Manhattan Chart**: Bar breakdown of runs scored and wickets in every single over.
  - **Pitch Impact Radar**: Visual 2D pitch map displaying ball lengths (Yorker, Full, Good Length, Short).
  - **Live Win Probability**: Dynamic percentage win predictor adapting ball-by-ball.
- 🔊 **Web Audio Synthesizer**: Realistic bat-on-ball cracks, boundary celebrations, and wicket sirens generated natively with browser Web Audio API (zero external assets needed).
- 📱 **Broadcast-Grade Dashboard**:
  - Dark stadium atmosphere with ambient lighting and metallic glassmorphic panels.
  - Live batsman crease cards with strike indicators (`★ ON STRIKE`), bowler spells, and 3D glowing ball chips.
  - Auto-scrolling ball-by-ball commentary with color-coded event badges.
  - Full detailed scorecard with batting, bowling, extras, and fall-of-wickets tables.
  - Manual Ball Scorer deck for external scorekeepers.

---

## 🏗️ Architecture

```mermaid
flowchart TD
    subgraph Client [Broadcast Web Client]
        UI[Responsive Live Center]
        Audio[Web Audio Synthesizer]
        Charts[Chart.js Worm & Manhattan]
        Radar[2D Pitch Radar]
        WS[SockJS + STOMP WebSocket Client]
    end

    subgraph SpringBoot [Spring Boot 3 / Java 21 Backend]
        REST[REST Controllers: /api/matches]
        Broker[STOMP Message Broker: /topic/match/{id}, /topic/matches]
        Sim[MatchSimulationEngine - Scheduled Tasks]
        Rules[ScoreCalculationService - Cricket Rules Engine]
        Service[MatchService]
    end

    subgraph Storage [Persistence Layer]
        JPA[Spring Data JPA Repositories]
        H2[(In-Memory H2 Database)]
    end

    Sim -->|Generates Deliveries| Rules
    Rules -->|Applies Scoring & Strike Rotation| Service
    Service -->|Persists State| JPA
    JPA --> H2
    Service -->|Broadcasts Live Deltas| Broker
    Broker -->|Real-Time Push| WS
    REST -->|Historical & Full Scorecards| UI
    WS --> UI
    UI --> Audio
    UI --> Charts
    UI --> Radar
```

---

## 🚀 Quick Start

### Prerequisites
- **Java 21** or higher
- **Maven 3.8+**

### 1. Clone & Build
```bash
git clone <repository-url>
cd cricket-score-management
mvn clean package
```

### 2. Run the Application
```bash
mvn spring-boot:run
```
*Or run the standalone JAR:*
```bash
java -jar target/cricket-score-management-1.0.0.jar
```

### 3. Open the Dashboard
Navigate to `http://localhost:8080` in your web browser.

- **H2 Database Web Console**: `http://localhost:8080/h2-console`
  - JDBC URL: `jdbc:h2:mem:cricketdb`
  - User: `sa`
  - Password: *(empty)*

---

## 📡 REST API Reference

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/matches` | Get summaries of all active, scheduled, and completed matches. |
| `GET` | `/api/matches/{id}` | Get live score, active striker, non-striker, and bowler data. |
| `GET` | `/api/matches/{id}/scorecard` | Get detailed scorecard for both innings. |
| `GET` | `/api/matches/{id}/commentary` | Paginated ball-by-ball commentary stream. |
| `GET` | `/api/matches/{id}/analytics` | Get Worm chart and Manhattan chart dataset points. |
| `POST` | `/api/matches` | Create a new custom match with teams and venue. |
| `POST` | `/api/matches/{id}/balls` | Manually record a ball delivery event. |
| `POST` | `/api/matches/{id}/simulation/control` | Control simulation (`START`, `PAUSE`, `STEP`, `RESET`, `SET_SPEED`). |

---

## ⚡ WebSocket Topics

- `/topic/matches`: High-level ticker updates for match lists.
- `/topic/match/{matchId}`: High-frequency ball-by-ball delta payloads.

---

## 🧪 Automated Testing

To run the automated suite testing cricket boundary scoring, strike rotation, extras, over completions, and REST endpoints:

```bash
mvn test
```

---

## 📄 License
MIT License. Built for sports fans and engineers.
